
// Particle Network Background - animated canvas with phase-reactive colors
const ParticleCanvas = ({ activePhase, phaseColors }) => {
  const canvasRef = React.useRef(null);
  const animRef = React.useRef(null);
  const particlesRef = React.useRef([]);
  const mouseRef = React.useRef({ x: -1000, y: -1000 });

  const PARTICLE_COUNT = 80;
  const CONNECTION_DIST = 160;
  const MOUSE_DIST = 200;

  React.useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    const resize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);

    // Initialize particles
    if (particlesRef.current.length === 0) {
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        particlesRef.current.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          r: Math.random() * 2 + 0.5,
          phase: Math.random() * Math.PI * 2,
        });
      }
    }

    const mousemove = (e) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener('mousemove', mousemove);

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const particles = particlesRef.current;
      const color = phaseColors[activePhase] || '#4ECDC4';
      const t = Date.now() * 0.001;

      // Update and draw particles
      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        p.x = Math.max(0, Math.min(w, p.x));
        p.y = Math.max(0, Math.min(h, p.y));

        // Mouse repulsion
        const dx = p.x - mouseRef.current.x;
        const dy = p.y - mouseRef.current.y;
        const md = Math.sqrt(dx * dx + dy * dy);
        if (md < MOUSE_DIST && md > 0) {
          const force = (MOUSE_DIST - md) / MOUSE_DIST * 0.02;
          p.vx += (dx / md) * force;
          p.vy += (dy / md) * force;
        }

        // Damping
        p.vx *= 0.999;
        p.vy *= 0.999;

        // Pulsing radius
        const pr = p.r * (1 + 0.3 * Math.sin(t * 1.5 + p.phase));

        ctx.beginPath();
        ctx.arc(p.x, p.y, pr, 0, Math.PI * 2);
        ctx.fillStyle = color + '60';
        ctx.fill();

        // Glow
        ctx.beginPath();
        ctx.arc(p.x, p.y, pr + 2, 0, Math.PI * 2);
        ctx.fillStyle = color + '15';
        ctx.fill();
      });

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < CONNECTION_DIST) {
            const alpha = Math.floor((1 - d / CONNECTION_DIST) * 30);
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = color + (alpha < 16 ? '0' : '') + alpha.toString(16);
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // Draw mouse connections
      particles.forEach(p => {
        const dx = p.x - mouseRef.current.x;
        const dy = p.y - mouseRef.current.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < MOUSE_DIST) {
          const alpha = Math.floor((1 - d / MOUSE_DIST) * 40);
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouseRef.current.x, mouseRef.current.y);
          ctx.strokeStyle = color + (alpha < 16 ? '0' : '') + alpha.toString(16);
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      });

      animRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', mousemove);
    };
  }, [activePhase, phaseColors]);

  return React.createElement('canvas', {
    ref: canvasRef,
    style: {
      position: 'fixed', top: 0, left: 0,
      width: '100%', height: '100%',
      zIndex: 0, pointerEvents: 'none',
    }
  });
};

// Grid overlay for sci-fi feel
const GridOverlay = () => {
  return React.createElement('div', {
    style: {
      position: 'fixed', top: 0, left: 0,
      width: '100%', height: '100%',
      zIndex: 0, pointerEvents: 'none',
      opacity: 0.03,
      backgroundImage: `
        linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
      `,
      backgroundSize: '60px 60px',
    }
  });
};

// Scan line effect
const ScanLine = () => {
  return React.createElement('div', {
    className: 'scan-line',
    style: {
      position: 'fixed', top: 0, left: 0,
      width: '100%', height: '100%',
      zIndex: 1, pointerEvents: 'none',
    }
  });
};

Object.assign(window, { ParticleCanvas, GridOverlay, ScanLine });
