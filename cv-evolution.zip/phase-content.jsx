
// Phase visualization components - all visibility driven by transitions, no CSS animations

// Single node in the knowledge graph
const GraphNode = ({ node, x, y, color, delay, onHover }) => {
  const [hovered, setHovered] = React.useState(false);
  const typeStyles = {
    milestone: { r: 18, glow: 36 },
    education: { r: 16, glow: 30 },
    work: { r: 14, glow: 26 },
    research: { r: 14, glow: 26 },
    project: { r: 12, glow: 22 },
    skill: { r: 10, glow: 18 },
    theme: { r: 9, glow: 16 },
    interest: { r: 9, glow: 16 },
    transition: { r: 12, glow: 22 },
  };
  const ts = typeStyles[node.type] || typeStyles.skill;

  return React.createElement('g', {
    style: { cursor: 'pointer' },
    onMouseEnter: () => { setHovered(true); onHover && onHover(node); },
    onMouseLeave: () => { setHovered(false); onHover && onHover(null); },
  },
    React.createElement('circle', {
      cx: x, cy: y, r: hovered ? ts.glow * 1.5 : ts.glow,
      fill: color + (hovered ? '50' : '25'),
      style: { transition: 'all 0.3s ease' },
    }),
    React.createElement('circle', {
      cx: x, cy: y, r: hovered ? ts.r * 1.3 : ts.r,
      fill: color,
      stroke: color, strokeWidth: 1.5,
      style: { transition: 'all 0.3s ease', filter: hovered ? `drop-shadow(0 0 10px ${color})` : `drop-shadow(0 0 4px ${color}60)` },
    }),
    React.createElement('text', {
      x: x, y: y + ts.r + 16,
      textAnchor: 'middle',
      fill: hovered ? '#fff' : '#ffffffcc',
      fontSize: node.type === 'milestone' || node.type === 'education' ? 14 : 12,
      fontFamily: "'Space Grotesk', sans-serif",
      fontWeight: node.type === 'milestone' ? 600 : 400,
      style: { transition: 'fill 0.3s ease' },
    }, node.label),
    node.detail && hovered ? React.createElement('text', {
      x: x, y: y + ts.r + 32,
      textAnchor: 'middle',
      fill: color + 'ee',
      fontSize: 10.5,
      fontFamily: "'JetBrains Mono', monospace",
    }, node.detail) : null
  );
};

// Node constellation for a phase
const NodeConstellation = ({ nodes, connections, color, layoutFn, isVisible }) => {
  const positions = React.useMemo(() => layoutFn(nodes), [nodes]);
  const [hovered, setHovered] = React.useState(null);

  return React.createElement('svg', {
    viewBox: '0 0 900 600',
    style: {
      width: '100%', maxWidth: 900, height: 'auto', overflow: 'visible',
    },
  },
    // Connection lines
    connections && connections.map((c, i) => {
      const p1 = positions[c[0]];
      const p2 = positions[c[1]];
      if (!p1 || !p2) return null;
      const isHighlighted = hovered && (nodes[c[0]]?.label === hovered.label || nodes[c[1]]?.label === hovered.label);
      return React.createElement('line', {
        key: `c-${i}`, x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y,
        stroke: isHighlighted ? color + '80' : color + '30',
        strokeWidth: isHighlighted ? 1.5 : 0.7,
        strokeDasharray: isHighlighted ? 'none' : '4 4',
        style: { transition: 'all 0.3s ease' },
      });
    }),
    // Nodes
    nodes.map((node, i) => {
      const pos = positions[i];
      return React.createElement(GraphNode, {
        key: node.label, node, x: pos.x, y: pos.y,
        color, delay: 0, onHover: setHovered,
      });
    })
  );
};

// Floating keywords
const FloatingKeywords = ({ keywords, color, isVisible }) => {
  return React.createElement('div', {
    style: {
      display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: 'center', maxWidth: 550,
    }
  },
    keywords.map((kw) => React.createElement('span', {
      key: kw,
      style: {
        color: color + 'bb',
        fontSize: 11,
        fontFamily: "'JetBrains Mono', monospace",
        letterSpacing: '0.05em',
        padding: '4px 10px',
        border: `1px solid ${color}30`,
        borderRadius: 2,
        textTransform: 'uppercase',
      }
    }, kw))
  );
};

// Phase section
const PhaseSection = ({ phase, index, isActive, color }) => {
  const emotionLabels = {
    0: 'CURIOUS · CHAOTIC · EXPLORATORY',
    1: 'ANALYTICAL AWAKENING',
    2: 'TRANSFORMATION',
    3: 'SYSTEMS MASTERY',
    4: 'CONVERGENCE',
  };

  return React.createElement('section', {
    className: `phase-section ${isActive ? 'phase-active' : ''}`,
    id: `phase-${index}`,
    style: { '--phase-color': color },
  },
    // Large phase number watermark
    React.createElement('div', { className: 'phase-number-bg' },
      React.createElement('span', { style: { color: color + '08' } }, `0${index + 1}`)
    ),

    // Content container
    React.createElement('div', { className: 'phase-content' },
      // Phase header - visibility via transitions
      React.createElement('div', {},
        React.createElement('div', { className: 'phase-meta' },
          React.createElement('span', {
            className: 'phase-index',
            style: { color, borderColor: color + '40' }
          }, `PHASE ${String(index + 1).padStart(2, '0')}`),
          React.createElement('span', {
            className: 'phase-dates',
            style: { color: color + '99' }
          }, phase.dates),
        ),
        React.createElement('h2', {
          className: 'phase-title',
          style: { color }
        }, phase.title),
        React.createElement('p', {
          className: 'phase-subtitle',
        }, phase.subtitle),
        React.createElement('div', {
          className: 'phase-emotion',
          style: { color: color + '70' }
        }, emotionLabels[index]),
      ),

      // Node constellation
      React.createElement('div', { className: 'phase-graph' },
        React.createElement(NodeConstellation, {
          nodes: phase.nodes,
          connections: phase.connections,
          color,
          layoutFn: phase.layout,
          isVisible: isActive,
        })
      ),

      // Keywords
      React.createElement('div', { className: 'phase-keywords' },
        React.createElement(FloatingKeywords, {
          keywords: phase.keywords,
          color,
          isVisible: isActive,
        })
      ),

      // Key metrics
      phase.metrics && React.createElement('div', {
        className: 'phase-metrics',
      },
        phase.metrics.map((m, i) => React.createElement('div', {
          key: i,
          className: 'metric-card',
          style: { borderColor: color + '30' },
        },
          React.createElement('div', { className: 'metric-value', style: { color } }, m.value),
          React.createElement('div', { className: 'metric-label' }, m.label),
        ))
      ),
    )
  );
};

// Side navigation
const PhaseNav = ({ phases, activePhase, colors, onNavigate }) => {
  return React.createElement('nav', { className: 'phase-nav' },
    phases.map((phase, i) => React.createElement('button', {
      key: i,
      className: `nav-dot ${activePhase === i ? 'nav-active' : ''}`,
      onClick: () => onNavigate(i),
      title: phase.title,
    },
      React.createElement('span', {
        className: 'nav-dot-inner',
        style: { backgroundColor: activePhase === i ? colors[i] : 'transparent', borderColor: colors[i] + (activePhase === i ? '' : '60') }
      }),
      React.createElement('span', {
        className: 'nav-label',
        style: { color: activePhase === i ? colors[i] : '#ffffff50' }
      }, phase.title)
    ))
  );
};

// Recurring themes
const RecurringThemes = ({ activePhase, colors }) => {
  const themes = [
    { label: 'MEANING', phases: [0,1,2,3,4] },
    { label: 'SYSTEMS', phases: [1,2,3,4] },
    { label: 'INEQUALITY', phases: [0,1,2] },
    { label: 'COGNITION', phases: [1,4] },
    { label: 'INTERPRETATION', phases: [0,1,4] },
    { label: 'STRUCTURE', phases: [1,2,3,4] },
    { label: 'HUMAN BEHAVIOR', phases: [0,1,2,3,4] },
  ];

  return React.createElement('div', { className: 'recurring-themes' },
    React.createElement('div', { className: 'themes-label' }, 'RECURRING THREADS'),
    themes.map((theme) => {
      const isActive = theme.phases.includes(activePhase);
      const color = isActive ? colors[activePhase] : '#ffffff20';
      return React.createElement('div', {
        key: theme.label,
        className: `theme-thread ${isActive ? 'thread-active' : ''}`,
        style: { color, transition: 'all 0.5s ease' },
      },
        React.createElement('span', { className: 'thread-dot', style: { backgroundColor: color, transition: 'all 0.5s ease' } }),
        React.createElement('span', { className: 'thread-label' }, theme.label),
      );
    })
  );
};

// Hero section
const HeroSection = ({ isActive, color }) => {
  return React.createElement('section', { className: 'hero-section', id: 'hero' },
    React.createElement('div', { className: 'hero-node' },
      React.createElement('div', { className: 'hero-node-ring ring-1', style: { borderColor: color + '20' } }),
      React.createElement('div', { className: 'hero-node-ring ring-2', style: { borderColor: color + '15' } }),
      React.createElement('div', { className: 'hero-node-ring ring-3', style: { borderColor: color + '10' } }),
      React.createElement('div', { className: 'hero-node-core', style: { backgroundColor: color, boxShadow: `0 0 40px ${color}40` } }),
    ),
    React.createElement('div', { className: 'hero-content' },
      React.createElement('div', { className: 'hero-overline' }, 'VISUAL KNOWLEDGE MAP'),
      React.createElement('h1', { className: 'hero-title' },
        React.createElement('span', { className: 'hero-title-line1' }, 'Evolution of an'),
        React.createElement('br'),
        React.createElement('span', { className: 'hero-title-line2', style: { color } }, 'AI Researcher'),
      ),
      React.createElement('div', { className: 'hero-divider', style: { backgroundColor: color + '40' } }),
      React.createElement('p', { className: 'hero-subtitle' }, 'From Sociology to Neuro-Symbolic AI'),
      React.createElement('p', { className: 'hero-name' }, 'Bálint Antal'),
      React.createElement('div', { className: 'hero-scroll-cue' },
        React.createElement('span', null, 'SCROLL TO EXPLORE'),
        React.createElement('div', { className: 'scroll-arrow', style: { borderColor: color + '60' } }),
      ),
    )
  );
};

// Convergence section
const ConvergenceSection = ({ colors, isActive }) => {
  const threads = [
    { from: 'Sociology', to: 'Social AI', color: colors[1] },
    { from: 'Philosophy', to: 'Interpretive AI', color: colors[0] },
    { from: 'Statistics', to: 'ML Engineering', color: colors[2] },
    { from: 'Wellbeing Research', to: 'Human-AI Systems', color: colors[3] },
    { from: 'Meaning-Making', to: 'Neuro-Symbolic AI', color: colors[4] },
  ];

  return React.createElement('section', {
    className: `convergence-section ${isActive ? 'phase-active' : ''}`,
    id: 'convergence',
  },
    React.createElement('div', {
      className: 'convergence-content',
    },
      React.createElement('div', { className: 'convergence-overline', style: { color: colors[4] } }, 'THE REVELATION'),
      React.createElement('h2', { className: 'convergence-title' },
        '"The entire journey was',
        React.createElement('br'),
        React.createElement('span', { style: { color: colors[4] } }, 'coherent'),
        ' all along."'
      ),
      React.createElement('div', { className: 'convergence-threads' },
        threads.map((t, i) => React.createElement('div', {
          key: i,
          className: 'convergence-thread',
          style: {},
        },
          React.createElement('span', { className: 'conv-from' }, t.from),
          React.createElement('span', { className: 'conv-arrow', style: { color: t.color } }, '→'),
          React.createElement('span', { className: 'conv-to', style: { color: t.color } }, t.to),
        ))
      ),
      React.createElement('p', { className: 'convergence-insight' },
        'Early sociology and philosophy evolved naturally into AI research. ',
        'The core motivation was always understanding complex human systems. ',
        'Data science and AI became tools for modeling meaning, behavior, and structure.'
      ),
    )
  );
};

// Phase transition divider between sections
const PhaseTransition = ({ fromColor, toColor, label, skills }) => {
  return React.createElement('div', {
    style: {
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '40px 20px', position: 'relative', zIndex: 2,
    }
  },
    React.createElement('div', {
      style: { width: 1, height: 60, background: `linear-gradient(${fromColor}40, ${toColor}40)` }
    }),
    React.createElement('div', {
      style: {
        width: 12, height: 12, borderRadius: '50%',
        background: `linear-gradient(135deg, ${fromColor}, ${toColor})`,
        boxShadow: `0 0 20px ${toColor}30`, margin: '8px 0',
      }
    }),
    React.createElement('div', {
      style: { display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', maxWidth: 400, margin: '12px 0' }
    },
      skills.map(s => React.createElement('span', {
        key: s,
        style: {
          fontSize: 9, fontFamily: "'JetBrains Mono', monospace",
          color: toColor + '90', letterSpacing: '0.06em',
          padding: '2px 8px', border: `1px solid ${toColor}20`, borderRadius: 1,
        }
      }, `+ ${s}`))
    ),
    React.createElement('div', {
      style: {
        fontFamily: "'JetBrains Mono', monospace", fontSize: 8,
        letterSpacing: '0.3em', color: toColor + '50', textTransform: 'uppercase', marginTop: 4,
      }
    }, label),
    React.createElement('div', {
      style: { width: 1, height: 60, background: `linear-gradient(${toColor}40, ${toColor}10)` }
    }),
  );
};

// Skill stacking visualization for convergence
const SkillStack = ({ colors }) => {
  const stacks = [
    { era: '2013', skills: ['Communication', 'Philosophy'], color: colors[0] },
    { era: '2016', skills: ['Sociology', 'Research', 'Econometrics'], color: colors[1] },
    { era: '2021', skills: ['SQL', 'Python', 'Pipelines'], color: colors[2] },
    { era: '2023', skills: ['PySpark', 'Azure', 'ML', 'MLOps'], color: colors[3] },
    { era: '2025', skills: ['GenAI', 'RAG', 'Neuro-Symbolic', 'React'], color: colors[4] },
  ];

  return React.createElement('div', {
    style: {
      display: 'flex', gap: 4, alignItems: 'flex-end',
      justifyContent: 'center', padding: '40px 20px 20px',
      position: 'relative', zIndex: 2,
    }
  },
    stacks.map((stack) => React.createElement('div', {
      key: stack.era,
      style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }
    },
      stack.skills.map((skill) => React.createElement('div', {
        key: skill,
        style: {
          width: 95, padding: '4px 6px',
          background: stack.color + '15', border: `1px solid ${stack.color}25`,
          fontSize: 8, fontFamily: "'JetBrains Mono', monospace",
          color: stack.color + 'cc', textAlign: 'center', letterSpacing: '0.04em',
        }
      }, skill)),
      React.createElement('div', {
        style: {
          fontSize: 10, fontFamily: "'JetBrains Mono', monospace",
          color: stack.color, marginTop: 6, fontWeight: 600,
        }
      }, stack.era),
    ))
  );
};

Object.assign(window, {
  GraphNode, NodeConstellation, FloatingKeywords,
  PhaseSection, PhaseNav, RecurringThemes,
  HeroSection, ConvergenceSection,
  PhaseTransition, SkillStack,
});
