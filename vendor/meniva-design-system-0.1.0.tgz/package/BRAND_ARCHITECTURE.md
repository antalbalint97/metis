# Brand Architecture — The Meniva Ecosystem

This document defines how **Meniva**, **Metis**, **Nullfal**, and **CtrlPlane** relate to one
another: what must stay consistent so they read as one family, and what is allowed (encouraged) to
vary so each has its own personality.

> Grounding: the shared accent DNA (cool teal→green→blue), the bordered-card pattern, the
> CSS-variable theming, and the generous rhythm already exist across the real projects (see
> [`audit/PROJECT_AUDIT.md`](audit/PROJECT_AUDIT.md) §4.2). This document formalizes them.

---

## 1. The model: one master brand, three expressions

```
                          ┌──────────────────────────┐
                          │          MENIVA          │   Master / umbrella
                          │  data · AI · systems ·   │   Consulting-grade,
                          │  analytics · automation  │   calm, credible, senior
                          └────────────┬─────────────┘
                                       │ shares: type system, spacing rhythm,
                                       │ layout logic, card/button system,
                                       │ section hierarchy, cool accent DNA
            ┌──────────────────────────┼──────────────────────────┐
            │                          │                          │
   ┌────────▼────────┐       ┌─────────▼─────────┐      ┌──────────▼─────────┐
   │      METIS      │       │     NULLFAL      │      │     CTRLPLANE      │
   │  education ·    │       │  learning product │      │  newsletter ·      │
   │  mentoring ·    │       │  · knowledge sys  │      │  editorial · take  │
   │  guided learning│       │  · dev-friendly   │      │  · systems thinking│
   │                 │       │                   │      │                    │
   │  warmer, human  │       │  modular, system, │      │  sharp, analytical,│
   │  encouraging    │       │  mono-forward     │      │  opinionated       │
   └─────────────────┘       └───────────────────┘      └────────────────────┘
        warm teal               deep-ocean teal+amber      ink + electric azure
        (#2A7E6E)               (#56D6D0 / #F5B84B)        (#14181F / #3B6FF6)
```

- **Meniva** is the umbrella and the visual "center of gravity." When in doubt, a sub-brand should
  feel like it *could* have come from Meniva — just with its own accent and tone.
- **Metis, Nullfal, CtrlPlane** are siblings, not children of each other. Each owns a distinct
  accent, hero mood, and voice, but inherits the same skeleton.

## 2. Relationship rules

| Question | Answer |
| --- | --- |
| Are these one product? | **No.** They are separate properties that share a design language. |
| Do they share a codebase? | **No.** They share **tokens + components** via this design system. |
| Can a user tell they're related? | **Yes** — same type rhythm, spacing, cards, buttons, section logic; same cool-accent family. |
| Can a user tell them apart? | **Yes** — accent color, hero mood, copy voice, iconography metaphor. |
| Who sets the baseline? | **Meniva** (master). Sub-brands override, never contradict, the baseline. |

## 3. What MUST stay consistent (the shared skeleton)

These are defined once in `tokens/core.json` + `src/components/` and are **not** overridden per brand
except through sanctioned tokens:

1. **Typographic system** — the *scale, weights, line-heights, and role names* (`display`, `sans`, `mono`).
   Families vary; the rhythm does not.
2. **Spacing rhythm** — one 4px-based scale; section padding cadence; container max-widths.
3. **Layout logic** — centered max-width containers (content / wide / marketing), header band → main → footer.
4. **Card system** — bordered surface + subtle shadow + consistent padding + badge/bullet conventions.
5. **Button system** — same variant set (`primary / secondary / outline / ghost / link`) and sizes.
6. **Section hierarchy** — `overline → heading → lede → body/grid`, via the shared `SectionHeader`.
7. **Elevation & focus** — restrained, low-opacity shadows; consistent focus ring driven by `--ring`.
8. **The cool accent constraint** — every brand accent lives in the **cyan / teal / green / blue** arc.

## 4. What MAY vary per brand (the personality layer)

| Lever | How it varies | Token / mechanism |
| --- | --- | --- |
| **Accent color** | distinct hue per brand (still cool) | `--color-primary`, `--color-accent` (brand JSON) |
| **Surface warmth** | warm off-white (Metis) ↔ cool near-white (Meniva/CtrlPlane) ↔ deep navy, dark-first (Nullfal) | `--color-background/-surface` |
| **Radius personality** | soft (Metis) ↔ sharp (Meniva, CtrlPlane) ↔ rounded-modern (Nullfal) | `--radius` scale (brand override) |
| **Hero mood** | calm panel (Metis) ↔ high-impact display (Meniva, CtrlPlane) ↔ modular/dashboard (Nullfal) | `Hero` props + `tone` |
| **Display weight/casing** | semibold sentence-case (Metis) ↔ black uppercase (Meniva/CtrlPlane) | `--font-display`, heading utilities |
| **Iconography metaphor** | see §5 | component content |
| **Editorial emphasis** | educational ↔ consulting ↔ product ↔ editorial | copy + layout density |
| **Optional dark mode** | **Nullfal & CtrlPlane ship dark-first**; Meniva/Metis light-first with optional dark | `[data-theme="dark"]` |

## 5. Per-brand identity summary

### Meniva — *the expert partner*
- **Role:** umbrella; data/AI/analytics/automation/business systems consulting.
- **Feel:** calm, credible, outcome-oriented, senior, consulting-grade. Turns complexity into clarity and action.
- **Visual:** cool cyan-teal `#25B5C4` accent on clean near-white; **sharp-ish** edges; high-impact but disciplined hero; generous spacing; stat-driven proof.
- **Icon metaphor:** systems, flows, nodes, dashboards, geometric infrastructure.
- **Hero mood:** confident statement headline + measurable outcomes (stat row).

### Metis — *the patient mentor*
- **Role:** personal education, mentoring, guided learning (data/analytics thinking).
- **Feel:** warmer, more human, encouraging — but still structured and professional, never childish.
- **Visual:** warm muted teal-green `#2A7E6E` on warm off-white `#FAF8F5`; **soft** rounded edges; calm bordered-panel hero; restrained type.
- **Icon metaphor:** paths, steps, growth, light/understanding, hand-drawn-adjacent warmth (kept tasteful).
- **Hero mood:** invitation to think, not a sales pitch.

### Nullfal — *the structured system* (a.k.a. "Deep Ocean")
- **Role:** learning **platform** / structured knowledge system / technical education product.
- **Feel:** efficient, modular, practical, developer-friendly. Product-like, system-oriented, calm-premium.
- **Visual:** **dark-first** deep-navy (`#07111F`) with **teal `#56D6D0`** primary + **amber `#F5B84B`**
  secondary; **rounded-modern** cards; **mono-forward** typography (Unbounded display + JetBrains Mono
  body); knowledge-graph / skill-path hero with subtle glow.
- **Icon metaphor:** knowledge graph, nodes & cascades, skill-tree "journey", codex, terminal, modules, XP.
- **Hero mood:** "learn engineering as a system — here is your path through the graph."
- **Wordmark / tagline:** "NULLFAL" (NULL bright, FAL muted) · *"Graph-native Engineering Education."*
- **Extraction:** taken directly from `nullfall-minimal` (`theme.js` deepOcean + `index.css` + the real
  `NullfalLogo`). The earlier cyberpunk-neon concept is retired in favor of this calmer Deep Ocean look.

### CtrlPlane — *the control plane for understanding* (greenfield)
- **Role:** professional newsletter / editorial layer — AI, data, software, systems thinking, career/tech strategy.
- **Feel:** sharper, more analytical, more opinionated. A "control plane" for making sense of the field.
- **Visual:** **ink** `#14181F` + **electric azure** `#3B6FF6` accent; **sharp** edges; **dark-first** editorial option; tight, high-contrast typography; signal/terminal motifs.
- **Icon metaphor:** control planes, dashboards, signals, layers, switches, telemetry.
- **Hero mood:** a strong point of view + an issue/archive index.

## 5.5 Logo system — the MMNC lettermark family

The four brands share a **lettermark** logo system, not a single shared icon. Each mark is a single
letter, and together they spell the family mnemonic **MMNC**:

| Brand | Letter | Mark direction | Reads as |
| --- | --- | --- | --- |
| **Meniva** | **M** | the existing official blade-`M` (source of truth) | bold, master, consulting-grade |
| **Metis** | **M** | open, rounded `M` + a guiding point of light above the path | warmer, human, mentoring, guided learning |
| **Nullfal** | **N** | `N` wired with graph nodes (emphasized on the diagonal) | technical, modular, graph-native platform |
| **CtrlPlane** | **C** | a sharp `C` arc enclosing a centered signal point | analytical, editorial, control-plane / signal lens |

**Shared visual grammar (what makes them one family):**
- a common **32×32 optical grid** and matched optical size,
- one shared **stroke weight** and corner discipline,
- a recurring **node/dot accent** used differently per brand (Metis = a single guiding point,
  Nullfal = graph nodes, CtrlPlane = a central signal point),
- the same **mark→wordmark spacing**, baseline, and alignment rules (via `LogoLockup`),
- **light/dark + icon-only + horizontal** lockup variants for every brand.

**Distinct personality (what keeps them apart):** Meniva is the heaviest, filled master mark; Metis is
softer and more open; Nullfal is the most structural/modular; CtrlPlane is the sharpest and most
signal-like. They are deliberately **related but not identical** — Metis is not a recolored Meniva, and
Nullfal/CtrlPlane do not reuse the Meniva symbol.

**Color & theming.** Meniva carries its own cyan (it is a raster asset). The Metis, Nullfal, and
CtrlPlane marks are vector and paint with `currentColor`, so they inherit each brand's accent token and
work on both light and dark surfaces.

> **Status — provisional.** The Metis, Nullfal, and CtrlPlane marks are intentionally designed,
> system-consistent **placeholder lettermarks** that hold the brand grammar until final logo assets are
> produced. They live in [`src/components/LogoLockup.tsx`](src/components/LogoLockup.tsx) and can be
> replaced wholesale, or overridden per-use via the `LogoLockup` `mark` prop, without touching any other
> component. Meniva already uses its real asset (`assets/logos/meniva_mark.png`).

## 6. Practical rules for new pages & components

1. **Start from Meniva.** Build the structure with shared components and the *current brand's* tokens;
   never hard-code a brand color.
2. **Set the brand once** at the top of the tree via `data-brand="<brand>"` (and optionally
   `data-theme="dark"`). Everything below inherits.
3. **Express personality through tokens + tone, not new structure.** If two brands need genuinely
   different structure, add a *variant prop* to a shared component — don't fork the component.
4. **Stay inside the constraints:** cool accent, restrained elevation, consistent spacing, shared
   section hierarchy. Distinctiveness comes from accent + voice + mood, not from breaking the skeleton.
5. **No inline hex.** Always reference semantic tokens (`var(--color-primary)` / `bg-primary`).
6. **When a brand needs something truly unique** (e.g., Nullfal's code editor, CtrlPlane's issue
   archive), build it *in the brand's own app* using these tokens — promote it into the design system
   only if a second brand needs it.

## 7. Adding a brand later

A new brand = one `tokens/brands/<brand>.json` + one `[data-brand="<brand>"]` block in
`src/styles/tokens.css` + a voice entry here and in `VOICE_AND_TONE.md`. No component changes required.
See [`README.md`](README.md) → "How to add a new brand".
