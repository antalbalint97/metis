# @meniva/design-system

The shared **design system** for the Meniva ecosystem — **Meniva**, **Metis**, **Nullfal**, and
**CtrlPlane**. One skeleton (typography, spacing, layout, cards, buttons, section hierarchy), four
personalities (accent, surface, radius, hero mood, voice), switched with a single `data-brand`
attribute.

It is the canonical source of truth: design **tokens** (JSON) → **CSS variables** → **React
components** → **brand docs** → **examples**. The existing projects are **not** merged or moved here —
this system was *extracted* from them (see [`audit/PROJECT_AUDIT.md`](audit/PROJECT_AUDIT.md)) and is
meant to be adopted incrementally.

> Status: `v0.1.0`, `private` (not published). Built to become `@meniva/design-system` later without
> restructuring. Nothing in `metis-blog`, `meniva`, or `nullfall-minimal` was modified to create it.

---

## What's inside

| Layer | Path | Purpose |
| --- | --- | --- |
| Audit | `audit/PROJECT_AUDIT.md` | Evidence-based review of the 3 real projects + open questions |
| Strategy | `BRAND_ARCHITECTURE.md`, `DESIGN_PRINCIPLES.md`, `VOICE_AND_TONE.md` | The rules: what's shared, what varies, how each brand sounds |
| Tokens | `tokens/core.json`, `tokens/brands/*.json` | The values (source of truth) |
| CSS | `src/styles/tokens.css`, `src/styles/components.css` | Runtime CSS variables + component styles |
| Components | `src/components/*` + `src/components/README.md` | 11 typed, brand-agnostic React components |
| Examples | `examples/*.example.tsx` | One home page per brand from the same kit |
| Preview | `preview/` + `LOCAL_PREVIEW.md` | Local **Design Lab** (Vite) to inspect everything before `/design-sync` |
| Sync | `CLAUDE_DESIGN_SYNC.md` | How to drive it with Claude Design `/design-sync` |

## Brand architecture (in one breath)

**Meniva** is the master (data/AI/consulting — calm, credible, cyan). **Metis** (education/mentoring —
warm, teal-green), **Nullfal** (learning platform — dark "Deep Ocean", teal + amber), and **CtrlPlane** (editorial
newsletter — sharp, ink + azure) are siblings that inherit Meniva's skeleton and differ only by accent,
mood, and voice. Every accent stays in the **cool cyan/teal/green/blue** arc — the family's shared DNA.
Full detail in [`BRAND_ARCHITECTURE.md`](BRAND_ARCHITECTURE.md).

## Folder structure

```
meniva-design-system/
├── README.md                     ← you are here
├── BRAND_ARCHITECTURE.md         ← relationships, what's shared vs. per-brand
├── DESIGN_PRINCIPLES.md          ← 7 principles + do/don't
├── VOICE_AND_TONE.md             ← per-brand voice, copy examples
├── CLAUDE_DESIGN_SYNC.md         ← /design-sync usage + prompts
├── package.json                  ← @meniva/design-system (private, future-proof)
├── tsconfig.json
├── audit/
│   └── PROJECT_AUDIT.md          ← the Phase-1 audit
├── tokens/
│   ├── core.json                 ← shared tokens (source of truth)
│   └── brands/
│       ├── meniva.json  metis.json  nullfal.json  ctrlplane.json
├── src/
│   ├── index.ts                  ← public exports
│   ├── lib/{cn.ts, renderAction.tsx}
│   ├── styles/{tokens.css, components.css}
│   └── components/
│       ├── Button  Card  SectionHeader  Hero  Navbar  Footer
│       ├── ServiceCard  CourseCard  ArticleCard  NewsletterSignup  LogoLockup
│       └── README.md             ← per-component docs
└── examples/
    └── {meniva,metis,nullfal,ctrlplane}-home.example.tsx
```

---

## Local preview (Design Lab)

A local, browser-based **Design Lab** for inspecting the whole system — every component, all four brands,
light/dark/muted/card surfaces, responsive widths, states, edge cases and the real example pages. It
renders the **actual** components and stylesheets (nothing is duplicated), so it is the primary preview
mechanism. Use it **before** the slow, billed `/design-sync`.

```bash
npm install     # first run (adds vite + @vitejs/plugin-react)
npm run dev     # → http://localhost:5173
```

- **Brand switcher** (top bar) recolors everything via `data-brand`; pages also compare brands side by side.
- **Responsive frames** use real iframes so components' `@media` breakpoints fire at 320 / 375 / 768 / 1024 / full.
- **Priority checks:** the LogoLockup MMNC matrix and the NewsletterSignup dark/in-card variant at 320px.

Run `/design-sync` **only after** the local visual pass is green. Full guide:
[`LOCAL_PREVIEW.md`](LOCAL_PREVIEW.md).

---

## How to use the tokens

Tokens flow **`tokens/*.json` → `src/styles/tokens.css` → your UI`**. In an app, import the CSS and set
the brand:

```tsx
// app root (Next layout.tsx, CRA index.js, etc.)
import "@meniva/design-system/styles/tokens.css";
import "@meniva/design-system/styles/components.css";
```

```html
<html data-brand="meniva">            <!-- light -->
<html data-brand="ctrlplane" data-theme="dark">  <!-- dark -->
```

Then consume the semantic variables anywhere — in plain CSS, inline styles, or Tailwind arbitrary values:

```css
.thing { background: var(--color-surface); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius-lg); }
```

The semantic names are stable across brands: `--color-background`, `--color-surface`,
`--color-surface-muted`, `--color-text`, `--color-text-muted`, `--color-border`, `--color-primary`
(+`-foreground`/`-hover`), `--color-accent` (+`-foreground`/`-muted`), `--color-link`, `--color-ring`,
plus `--radius-*`, `--shadow-*`, `--space-*`, `--text-*`, `--font-*`, `--container-*`, `--z-*`,
`--duration-*`, `--ease-*`. Changing `data-brand` re-resolves all of them — no component edits.

**Tailwind users:** map utilities to these variables once. v4 → copy the `@theme inline` block at the
bottom of `tokens.css`. v3 → add `colors: { surface: 'var(--color-surface)', … }` in `tailwind.config`.

## How to use the components

```tsx
import { Navbar, Hero, ServiceCard, Footer, LogoLockup } from "@meniva/design-system";

export default function Page() {
  return (
    <div data-brand="meniva" className="ds-base">
      <Navbar logo={<LogoLockup brand="meniva" href="/" />} action={{ label: "Contact", href: "/contact" }} />
      <main className="ds-container ds-container--marketing ds-section">
        <Hero
          variant="display" align="center"
          overline="DATA · AI · AUTOMATION"
          title="Data & AI systems for modern teams"
          primaryAction={{ label: "Book a consultation", href: "/contact" }}
        />
      </main>
      <Footer logo={<LogoLockup brand="meniva" />} copyright="© 2026 Meniva" />
    </div>
  );
}
```

Components are styled with token-based `ds-*` classes (not project-specific Tailwind), so they work
identically in Next.js (v4) and CRA (v3) and plain React. Full API in
[`src/components/README.md`](src/components/README.md). Runnable references in
[`examples/`](examples/).

## How to add a new brand

1. **Tokens:** copy a brand file → `tokens/brands/<brand>.json`; set `color`, `typography.fontFamily`,
   `radius`, and (optionally) `dark`. Keep the accent in the cool arc.
2. **CSS:** add a `[data-brand="<brand>"] { … }` block (and a dark block) to
   [`src/styles/tokens.css`](src/styles/tokens.css), mirroring the JSON.
3. **Voice:** add a section to [`VOICE_AND_TONE.md`](VOICE_AND_TONE.md) and a row in
   [`BRAND_ARCHITECTURE.md`](BRAND_ARCHITECTURE.md).
4. **(Optional)** add `examples/<brand>-home.example.tsx` and `<brand>` to the `BrandId` union in
   `src/index.ts`.
5. Re-run `/design-sync`. **No component code changes are required.**

## How to run `/design-sync`

```bash
cd Pet_projects/meniva-design-system
claude
/design-sync
```

See [`CLAUDE_DESIGN_SYNC.md`](CLAUDE_DESIGN_SYNC.md) for ready-to-use prompts per brand and the rules to
remind Claude Design of.

## Local checks

```bash
npm install            # peer/dev deps (React + TypeScript)
npm run validate:tokens  # assert all token JSON parses
npm run typecheck        # tsc --noEmit over src + examples
```

---

## Next steps — integrating into the existing projects (incremental, non-destructive)

Adopt in this order; each step is reversible and doesn't require restructuring:

1. **Resolve the open questions** in [`audit/PROJECT_AUDIT.md`](audit/PROJECT_AUDIT.md) §5 — Nullfal's
   identity is now resolved (the correct repo is `nullfall-minimal` → dark "Deep Ocean" platform);
   Meniva's light/dark polarity is confirmed **light-first + optional dark**.
2. **Adopt tokens first, everywhere.** Drop `tokens.css` into each app and set `data-brand`. Map the
   existing CSS variables to the semantic names. This aligns colors/spacing with zero component churn.
3. **metis-blog** (closest fit): alias its current vars to the shared names; optionally replace bespoke
   cards/buttons with the kit. Low risk — its system already matches.
4. **meniva** (Next + v4 + TS, already semantic): alias its `--brand`/`--surface` vars to the shared
   names and set `data-brand="meniva"`; optionally adopt the shared `Hero`/`ServiceCard`/`Navbar`/`Footer`.
   Low risk — same Next/v4 family as metis-blog. (The old CRA `meniva-modern` prototype can be retired.)
5. **nullfall-minimal**: it already ships the Deep Ocean tokens; alias its `theme.js`/`index.css` vars to
   the shared semantic names and adopt `data-brand="nullfal" data-theme="dark"` for platform chrome.
6. **CtrlPlane**: greenfield — start it directly on this system (`data-brand="ctrlplane"`,
   dark-first) using the `ctrlplane-home` example as the seed.
7. **Promote, don't fork.** When a brand needs a new shared pattern, add it here (token or component)
   rather than diverging.
8. **Later packaging:** when ready, add a build step (e.g. `tsup`), emit `dist/`, flip `private`, and
   repoint `exports` — the structure already anticipates this (see `package.json`).

## License / publishing

`UNLICENSED` and `private: true` on purpose — nothing is published. See the `publishConfig.note` in
`package.json` for how to turn this into a real published package later.
