import * as React from "react";
import { cn } from "../lib/cn";

export type FooterColumn = {
  title: string;
  links: { label: string; href: string }[];
};

export type FooterProps = {
  /** Brand logo node — typically a <LogoLockup />. */
  logo?: React.ReactNode;
  /** Short brand sentence under the logo. */
  tagline?: string;
  columns?: FooterColumn[];
  /** Social icons / links node, shown in the bottom bar. */
  social?: React.ReactNode;
  /** Copyright line (left of the bottom bar). Defaults to the current year. */
  copyright?: string;
  /** Optional extra node on the right of the bottom bar. */
  bottomNote?: React.ReactNode;
  container?: "content" | "wide" | "marketing";
  className?: string;
};

/**
 * Footer — structured footer: brand block + link columns + a bottom bar.
 * All sections are optional, so the same component serves Metis's minimal
 * footer and Meniva's larger marketing footer.
 */
export function Footer({
  logo,
  tagline,
  columns = [],
  social,
  copyright,
  bottomNote,
  container = "wide",
  className,
}: FooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer className={cn("ds-footer", className)}>
      <div className={cn("ds-container", `ds-container--${container}`)}>
        {(logo || tagline || columns.length > 0) && (
          <div className="ds-footer__top">
            <div>
              {logo}
              {tagline ? <p className="ds-footer__tagline">{tagline}</p> : null}
            </div>

            {columns.map((col) => (
              <div key={col.title}>
                <div className="ds-footer__col-title">{col.title}</div>
                <ul className="ds-footer__links">
                  {col.links.map((l) => (
                    <li key={l.href}>
                      <a className="ds-footer__link" href={l.href}>
                        {l.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        <div className="ds-footer__bottom">
          <span>{copyright ?? `© ${year}`}</span>
          {social ? <div>{social}</div> : null}
          {bottomNote ? <div>{bottomNote}</div> : null}
        </div>
      </div>
    </footer>
  );
}
