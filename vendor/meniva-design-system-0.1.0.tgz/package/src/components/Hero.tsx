import * as React from "react";
import { cn } from "../lib/cn";
import { renderAction } from "../lib/renderAction";
import type { Action } from "./types";

export type HeroStat = { value: string; label: string };

export type HeroProps = {
  overline?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  primaryAction?: Action;
  secondaryAction?: Action;
  /**
   * - "display": high-impact headline (Meniva, CtrlPlane)
   * - "panel":   calm bordered surface (Metis)
   * - "split":   copy + media side-by-side (Nullfal, Meniva product)
   */
  variant?: "display" | "panel" | "split";
  align?: "left" | "center";
  /** Right-hand media for the "split" variant (image, illustration, dashboard). */
  media?: React.ReactNode;
  /** Optional proof stats row (Meniva-style). */
  stats?: HeroStat[];
  /** Extra content rendered under the actions. */
  children?: React.ReactNode;
  className?: string;
};

/**
 * Hero — the section hierarchy of the system, scaled up. The `variant` carries
 * the per-brand "hero mood" while keeping the same underlying structure
 * (overline -> title -> description -> actions [-> stats / media]).
 */
export function Hero({
  overline,
  title,
  description,
  primaryAction,
  secondaryAction,
  variant = "display",
  align = "left",
  media,
  stats,
  children,
  className,
}: HeroProps) {
  const copy = (
    <div className="ds-hero__inner">
      {overline ? <span className="ds-overline">{overline}</span> : null}
      <h1 className="ds-hero__title">{title}</h1>
      {description ? <p className="ds-hero__desc">{description}</p> : null}

      {(primaryAction || secondaryAction) && (
        <div className="ds-hero__actions">
          {renderAction(primaryAction, "primary", "lg")}
          {renderAction(secondaryAction, "outline", "lg")}
        </div>
      )}

      {children}

      {stats && stats.length > 0 ? (
        <div className="ds-hero__stats">
          {stats.map((s, i) => (
            <div key={i}>
              <div className="ds-stat__value">{s.value}</div>
              <div className="ds-stat__label">{s.label}</div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );

  if (variant === "split") {
    return (
      <section
        className={cn("ds-hero", "ds-hero--split", align === "center" && "ds-hero--center", className)}
      >
        <div className="ds-hero__split">
          {copy}
          {media ? <div className="ds-hero__media">{media}</div> : null}
        </div>
      </section>
    );
  }

  return (
    <section
      className={cn(
        "ds-hero",
        `ds-hero--${variant}`,
        align === "center" && "ds-hero--center",
        className
      )}
    >
      {copy}
    </section>
  );
}
