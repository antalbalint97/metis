import * as React from "react";
import { cn } from "../lib/cn";
import { Card } from "./Card";
import { renderAction } from "../lib/renderAction";
import type { Action } from "./types";

export type ServiceCardProps = {
  /** Small icon node (e.g. a lucide/phosphor icon). Sits in an accent tile. */
  icon?: React.ReactNode;
  title: string;
  description: React.ReactNode;
  /** Optional feature/benefit bullet list. */
  features?: string[];
  action?: Action;
  interactive?: boolean;
  className?: string;
};

/**
 * ServiceCard — consulting/offering card (Meniva "Services" grid, but brand-
 * agnostic). Icon tile + title + description + optional features + footer CTA.
 */
export function ServiceCard({
  icon,
  title,
  description,
  features,
  action,
  interactive = true,
  className,
}: ServiceCardProps) {
  return (
    <Card padding="md" interactive={interactive} className={cn("ds-service-card", className)}>
      {icon ? <span className="ds-service-card__icon">{icon}</span> : null}
      <h3 className="ds-service-card__title">{title}</h3>
      <p className="ds-service-card__desc">{description}</p>

      {features && features.length > 0 ? (
        <ul className="ds-service-card__features">
          {features.map((f, i) => (
            <li key={i} className="ds-bullet">
              {f}
            </li>
          ))}
        </ul>
      ) : null}

      {action ? (
        <div className="ds-service-card__footer">{renderAction(action, "outline", "sm")}</div>
      ) : null}
    </Card>
  );
}
