import * as React from "react";

/**
 * Action — a shared shape for CTAs used by Hero, Navbar, Footer, cards, etc.
 * Provide `href` for links or `onClick` for buttons (or both). Kept framework-
 * neutral on purpose: pass a Next `<Link>`-wrapped node via `render` when you
 * need client-side routing, otherwise a plain anchor is used.
 */
export type Action = {
  label: string;
  href?: string;
  onClick?: React.MouseEventHandler;
  /** Optional: render the action with your own element (e.g. Next.js <Link>). */
  render?: (props: { className: string; children: React.ReactNode }) => React.ReactNode;
};

/** A single navigation entry. */
export type NavItem = {
  label: string;
  href: string;
  active?: boolean;
  icon?: React.ReactNode;
};
