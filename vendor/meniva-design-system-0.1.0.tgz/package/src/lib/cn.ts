/**
 * cn — tiny, dependency-free className joiner.
 * Filters out falsy values so you can write `cn("base", active && "is-active")`.
 * (Intentionally not `tailwind-merge`: components use token-based `ds-*` classes,
 * not conflicting Tailwind utilities, so simple joining is enough.)
 */
export function cn(
  ...parts: Array<string | number | false | null | undefined>
): string {
  return parts.filter(Boolean).join(" ");
}
