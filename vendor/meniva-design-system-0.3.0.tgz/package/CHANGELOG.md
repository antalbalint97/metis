# Changelog

All notable changes to `@meniva/design-system` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
this package follows [Semantic Versioning](https://semver.org/).

## [0.3.0] — 2026-06-26

MMNC brand-family **Phase C**: the shared system that makes the four brands read
as one family. DS-only — no consumer was modified or re-vendored. Changes are
visual where noted; consumers opt in by re-vendoring 0.3.0.

### Added
- **Layout primitives** — `PageContainer` (centered `prose|content|wide|marketing`
  band; default `wide`) and `Section` (responsive vertical rhythm `tight|default|lg`,
  optional `container`, optional leading `SectionHeader` rendered *inside* the
  container). Replace hand-written `max-w-[...]` + `py-24` in consumers.
- **Semantic radius roles** — `--radius-control`, `--radius-card`, `--radius-panel`,
  `--radius-pill`, set per brand. Components now prefer these over the numeric
  `--radius-lg`/`--radius-xl` scale (the scale is kept for compatibility).
- **Semantic Card padding** — `compact` (24) / `default` (32) / `feature` (40);
  `sm`/`md`/`lg` retained as aliases (sm→compact, md→default, lg→feature).
- **Shell + section tokens** — `--navbar-h` (72) / `--navbar-h-sm` (64);
  `--space-section-y-md` (64) / `--space-section-y-sm` (48).
- **Design Lab** — new “PageContainer & Section” section; the Lab now loads
  IBM Plex Sans, IBM Plex Mono, and the brand display faces (Outfit, Fraunces,
  Unbounded, Inter Tight) for accurate previews.

### Changed (visual — opt-in via re-vendor)
- **Shared body/UI font → IBM Plex Sans**; **shared mono → IBM Plex Mono**
  (was Inter / JetBrains Mono). Per brand: Meniva body unchanged (already Plex
  Sans); Metis & CtrlPlane move off Inter; **Nullfall body moves off mono**
  (Plex Mono is now restricted to code/metadata/labels/graph/system-state).
  Display faces unchanged (Outfit / Fraunces / Unbounded / Inter Tight).
- **Card radius two-step system** — 8px (Meniva, CtrlPlane) / 16px (Metis,
  Nullfall); feature/panel 24px. Controls are 8px (sharp) / 12px (soft).
- **Card padding** increased: 16/20/32 → **24/32/40**.
- **Navbar height** 64 → **72px** on desktop (64 on mobile).
- **Section spacing** is now responsive (48 → 64 → 96; lg 64 → 96 → 128).
- **`--container-marketing`** 1280 → **1240px**.
- **Motion** `--duration-fast` 150→**160ms**, `--duration-base` 200→**240ms**.

### Font-loading contract
- The package adds **no remote font `@import`**. It names families + fallbacks
  only; consumers load the actual faces (next/font for Next apps; self-hosted /
  controlled load for the CRA app). The Design Lab loads its own fonts.

### Preserved (no breaking API change)
- `Card` `padding` still accepts `none|sm|md|lg`; all existing prop usage compiles.
- `nullfal` (single L) ⇄ `nullfall` token parity unchanged.
- Package resolution still points at `src/`; numeric radius scale retained.

## [0.2.0] — 2026-06-21

Turns the design system into a versioned, buildable, recoverable dependency
**without** redesigning the visual system. Fully backward compatible.

### Added
- **Library build** emitting `dist/` (`npm run build`): `tsc -p tsconfig.build.json`
  produces JS + `.d.ts`; `scripts/copy-assets.mjs` copies styles + tokens so
  `dist/` is self-contained. Zero new dependencies.
- **`tsconfig.build.json`** — emit-only build config (root `tsconfig.json` stays
  type-check-only and continues to cover the Design Lab + examples).
- **Package validation** — `npm run validate:package` asserts dist artifacts,
  nullfal/nullfall token parity, BrandId export, and tarball contents.
- **`nullfall` brand id alias.** `data-brand="nullfall"` (canonical) now renders
  the exact same tokens as `data-brand="nullfal"` (legacy). `BrandId`,
  `LogoLockup`, and the CSS token blocks accept both spellings.
- **`prepack`** script so the tarball always carries a fresh `dist/`.
- `dist` added to the published `files` whitelist.
- New docs: `CHANGELOG.md`, `MIGRATION.md`, `RELEASE_CHECKLIST.md`.

### Changed
- `build` now produces the library `dist/` (was: built the Design Lab preview).
  The preview build moved to **`build:preview`**.
- `publishConfig.note` updated to reflect that a `dist/` build now exists.

### Preserved (no behavior change)
- `npm run dev` Design Lab workflow (Vite, `root: "preview"`) is unchanged.
- Package resolution still points at **`src/`** (`exports`/`main`/`module`/`types`),
  so existing vendored-tarball consumers are unaffected. `dist/` is shipped but
  not yet the resolved entry — see [MIGRATION.md](MIGRATION.md).
- `nullfal` (single L) support is **not** removed.

## [0.1.0] — prior

- Initial source-only design system: tokens, per-brand themes via `data-brand`,
  and React components, distributed as a vendored `.tgz`.

[0.2.0]: #020--2026-06-21
[0.1.0]: #010--prior
