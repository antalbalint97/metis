import * as React from "react";
import { cn } from "../lib/cn";

export type CardProps = React.HTMLAttributes<HTMLDivElement> & {
  /**
   * Inner padding. Semantic names are canonical; `sm`/`md`/`lg` are kept as
   * backward-compatible aliases:
   *   compact (24px) = sm · default (32px) = md · feature (40px) = lg
   * Use "none" when the card hosts its own full-bleed layout.
   */
  padding?: "none" | "compact" | "default" | "feature" | "sm" | "md" | "lg";
  /** Adds hover lift + accent border. Use for clickable / linked cards. */
  interactive?: boolean;
  /** Render as a different element (e.g. "a", "article", "li"). */
  as?: React.ElementType;
};

/**
 * Card — the bordered-surface container used everywhere in the ecosystem
 * (the pattern is shared by all three audited projects). ServiceCard,
 * CourseCard, and ArticleCard build on top of it.
 */
export function Card({
  padding = "md",
  interactive = false,
  as: Tag = "div",
  className,
  ...rest
}: CardProps) {
  return (
    <Tag
      className={cn(
        "ds-card",
        padding !== "none" && `ds-card--pad-${padding}`,
        interactive && "ds-card--interactive",
        className
      )}
      {...rest}
    />
  );
}
