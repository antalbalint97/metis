import * as React from "react";
import { cn } from "../lib/cn";

export type PageContainerSize = "prose" | "content" | "wide" | "marketing";

export type PageContainerProps = React.HTMLAttributes<HTMLElement> & {
  /**
   * Centered max-width band:
   * - prose (680) / content (740): reading measures
   * - wide (1040): default page content
   * - marketing (1240): full marketing width
   */
  size?: PageContainerSize;
  /** Render as a different element (e.g. "main", "section", "div"). */
  as?: React.ElementType;
};

/**
 * PageContainer — the one centered, gutter-aware max-width band for the
 * ecosystem. Replaces hand-written `max-w-[...] mx-auto px-...` in consumers so
 * every page shares the same widths and gutters. Maps directly to the existing
 * `.ds-container` classes (no new CSS).
 */
export function PageContainer({
  size = "wide",
  as: Tag = "div",
  className,
  ...rest
}: PageContainerProps) {
  return (
    <Tag
      className={cn("ds-container", `ds-container--${size}`, className)}
      {...rest}
    />
  );
}
