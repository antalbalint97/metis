import * as React from "react";
import { cn } from "../lib/cn";
import { PageContainer, type PageContainerSize } from "./PageContainer";
import { SectionHeader, type SectionHeaderProps } from "./SectionHeader";

export type SectionSpacing = "tight" | "default" | "lg";

export type SectionProps = React.HTMLAttributes<HTMLElement> & {
  /** Vertical rhythm (responsive). default ≈ 96px desktop. */
  spacing?: SectionSpacing;
  /**
   * When set, the section's content is wrapped in a PageContainer of this size.
   * Defaults to `false` so a Section can sit inside an existing container
   * without introducing a nested one.
   */
  container?: false | PageContainerSize;
  /** Optional shared SectionHeader, rendered above the children (inside the container). */
  header?: SectionHeaderProps;
  /** Render as a different element. Defaults to "section". */
  as?: React.ElementType;
};

/**
 * Section — the shared vertical-rhythm wrapper. Standardizes section padding
 * across the family and, optionally, the content width (via `container`) and a
 * leading `SectionHeader`. The header is always rendered INSIDE the container
 * so it shares the content's width.
 */
export function Section({
  spacing = "default",
  container = false,
  header,
  as: Tag = "section",
  className,
  children,
  ...rest
}: SectionProps) {
  const body = (
    <>
      {header ? <SectionHeader {...header} /> : null}
      {children}
    </>
  );

  return (
    <Tag
      className={cn(
        "ds-section",
        spacing === "tight" && "ds-section--tight",
        spacing === "lg" && "ds-section--lg",
        className
      )}
      {...rest}
    >
      {container ? <PageContainer size={container}>{body}</PageContainer> : body}
    </Tag>
  );
}
