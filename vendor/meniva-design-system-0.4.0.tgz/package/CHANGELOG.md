# Changelog

All notable changes to `@meniva/design-system` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
this package follows [Semantic Versioning](https://semver.org/).

## [0.2.0] — 2026-06-21

Turns the design system into a versioned, buildable, recoverable dependency
**without** redesigning the visual system. Fully backward compatible.

### Added
- **Library build** emitting `dist/` (`npm run build`): `tsc -p tsconfig.build.json`
  produces JS + `.d.ts`; `scripts/copy-assets.mjs` copies styles + tokens so
  `dist/` is self-contained. Zero new dependencies.
- **`tsconfig.build.json`** — emit-only build config (root `tsconfig.json` stays
  type-check-only and continues to cover the Design Lab + examples).
- **Package validation** — `npm run validate:package` asserts dist artifacts,
  nullfal/nullfall token parity, BrandId export, and tarball contents.
- **`nullfall` brand id alias.** `data-brand="nullfall"` (canonical) now renders
  the exact same tokens as `data-brand="nullfal"` (legacy). `BrandId`,
  `LogoLockup`, and the CSS token blocks accept both spellings.
- **`prepack`** script so the tarball always carries a fresh `dist/`.
- `dist` added to the published `files` whitelist.
- New docs: `CHANGELOG.md`, `MIGRATION.md`, `RELEASE_CHECKLIST.md`.

### Changed
- `build` now produces the library `dist/` (was: built the Design Lab preview).
  The preview build moved to **`build:preview`**.
- `publishConfig.note` updated to reflect that a `dist/` build now exists.

### Preserved (no behavior change)
- `npm run dev` Design Lab workflow (Vite, `root: "preview"`) is unchanged.
- Package resolution still points at **`src/`** (`exports`/`main`/`module`/`types`),
  so existing vendored-tarball consumers are unaffected. `dist/` is shipped but
  not yet the resolved entry — see [MIGRATION.md](MIGRATION.md).
- `nullfal` (single L) support is **not** removed.

## [0.1.0] — prior

- Initial source-only design system: tokens, per-brand themes via `data-brand`,
  and React components, distributed as a vendored `.tgz`.

[0.2.0]: #020--2026-06-21
[0.1.0]: #010--prior
