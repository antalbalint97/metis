# Using this design system with Claude Design (`/design-sync`)

This design system is structured so **Claude Design** can read it as a source of truth and generate new
pages that already match the ecosystem. `/design-sync` ingests the tokens, components, and brand docs;
afterwards your prompts can stay short because Claude already knows the system.

---

## 1. Run a sync

```bash
cd Pet_projects/meniva-design-system
claude
/design-sync
```

`/design-sync` will pick up, in priority order:

1. `tokens/core.json` + `tokens/brands/*.json` — the values
2. `src/styles/tokens.css` — the runtime CSS variables + `[data-brand]` switch
3. `src/components/` + `src/components/README.md` — the component API
4. `BRAND_ARCHITECTURE.md`, `DESIGN_PRINCIPLES.md`, `VOICE_AND_TONE.md` — the rules
5. `examples/*.example.tsx` — reference compositions per brand

> Re-run `/design-sync` whenever you change tokens or add a component/brand, so Claude Design's picture
> stays current.

## 2. The golden rules to remind Claude Design of

Paste this alongside any generation prompt (or rely on the synced docs):

- Use components from `@meniva/design-system`; do not hand-roll buttons/cards.
- Use **only** semantic tokens / `ds-*` classes — **never inline hex** or raw Tailwind color utilities.
- Set the brand once via `data-brand="<brand>"` on the page wrapper (add `data-theme="dark"` for dark).
- Keep the shared skeleton; express brand identity through accent + hero `variant` + voice only.
- Follow `VOICE_AND_TONE.md` for copy in the target brand's voice.

## 3. Recommended prompts

### Meniva — consulting landing page
> Using `@meniva/design-system` with `data-brand="meniva"`, generate a consulting landing page.
> Use a centered `Hero variant="display"` with an overline, a confident outcome-focused headline, a
> dual CTA ("Book a free consultation" / "View our work"), and a 4-stat proof row. Follow with a
> `SectionHeader` + a 4-up `ServiceCard` grid (Data foundations, BI dashboards, ML & forecasting, AI
> automation), a demos section, an FAQ, and a `Footer`. Voice: calm, credible, senior (see
> VOICE_AND_TONE → Meniva). No inline hex; tokens only.

### Metis — mentoring / education page
> Using `@meniva/design-system` with `data-brand="metis"`, generate a Hungarian mentoring page.
> Open with a calm `Hero variant="panel"` inviting the reader to think (not a sales pitch). Add a
> `CourseCard` grid of learning tracks (Data Analyst, Data Scientist, ML Engineer, Software Engineer)
> with level badges and focus lists, then a warm mentor-program highlight `Card` and a testimonials
> section. Voice: warm, human, encouraging, never childish (VOICE_AND_TONE → Metis). Soft radius, warm
> surface — all from tokens.

### Nullfal — course / platform page
> Using `@meniva/design-system` with `data-brand="nullfal" data-theme="dark"`, generate a
> developer-friendly "Deep Ocean" learning-platform home (dark navy + teal + amber, Unbounded display +
> JetBrains Mono body). Use a `Hero variant="split"` with copy on the left and a mono-styled
> knowledge-graph / skill-path visual on the right. Add a `CourseCard` grid of tracks with mono `meta`
> lines and a visible-progress feel. Voice: efficient, modular, practical; tagline "Graph-native
> Engineering Education" (VOICE_AND_TONE → Nullfal). Tokens only; amber is `--color-accent-2`.

### CtrlPlane — newsletter landing page
> Using `@meniva/design-system` with `data-brand="ctrlplane" data-theme="dark"`, generate a dark
> editorial newsletter landing page. Use a `Hero variant="display"` with an opinionated headline
> ("Signal, not noise."), a grid of issue `ArticleCard`s (with ISSUE n / date / reading-time mono
> meta), and a `NewsletterSignup` subscribe block. Voice: sharp, analytical, opinionated
> (VOICE_AND_TONE → CtrlPlane). Ink + electric azure, sharp edges — tokens only.

## 4. Switching/adding brands during a session

- **Switch brand:** change the `data-brand` value on the wrapper — every token re-resolves; no other
  edits needed.
- **Add a brand:** create `tokens/brands/<brand>.json`, add a `[data-brand="<brand>"]` block to
  `src/styles/tokens.css`, add a voice entry to `VOICE_AND_TONE.md`, then re-run `/design-sync`.

## 5. Verifying output matches the system

After generation, sanity-check:
- [ ] No inline hex / no raw `bg-cyan-500`-style utilities — only tokens / `ds-*`.
- [ ] Brand set once via `data-brand` (+ `data-theme` if dark).
- [ ] Components come from the kit (no bespoke button/card).
- [ ] Copy is in the brand's voice (VOICE_AND_TONE).
- [ ] Accent stays in the cool cyan/teal/green/blue arc.
- [ ] AA contrast + visible focus rings intact.
