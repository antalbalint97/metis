# Design Principles — Meniva Ecosystem

Seven principles that govern every page and component across Meniva, Metis, Nullfal, and CtrlPlane.
They exist to keep the family coherent while letting each brand breathe. They are derived from the
strongest, most consistent ideas observed in the real projects (see
[`audit/PROJECT_AUDIT.md`](audit/PROJECT_AUDIT.md) §4.4).

---

## 1. Clarity over decoration
Calm, premium, structured. Every element earns its place. Whitespace is a feature, not a gap.
- **Do:** generous vertical rhythm (`section` padding `py-20…py-32`), one clear primary action per view.
- **Don't:** competing CTAs, dense gradients, ornamental flourishes, or empty gamification spectacle.

## 2. Tokens are the single source of truth
All color, type, spacing, radius, and elevation flow from `tokens/*.json` → `tokens.css` → components.
- **Do:** `bg-surface text-text border-border`, `var(--color-primary)`.
- **Don't:** inline hex (`text-[#52525B]`), per-component palettes, or duplicated token layers
  (both were observed in the `meniva-modern` prototype and are explicitly disallowed here).

## 3. One skeleton, many skins
Structure is shared; identity is a thin token + tone layer on top. Brands differ by **accent, surface
warmth, radius, hero mood, and voice** — never by reinventing cards, buttons, or section hierarchy.
- **Do:** switch identity with a single `data-brand` attribute.
- **Don't:** fork a component to change a color. Add a token or a variant prop instead.

> **Logo note.** Identity also lives in the **MMNC lettermark family** (Meniva M · Metis M · Nullfal N ·
> CtrlPlane C) rendered by `LogoLockup` — one shared grammar, four distinct marks, *not* a single shared
> icon. The Metis, Nullfal, and CtrlPlane marks are **provisional, system-consistent placeholders** and
> can be replaced by final assets later via the `mark` prop. See
> [`BRAND_ARCHITECTURE.md`](BRAND_ARCHITECTURE.md) §5.5.

## 4. Restrained, purposeful elevation & motion
Shadows are low-opacity and few (a 4-step scale). Motion is subtle and meaningful (entrance fades,
hover affordances), never decorative spectacle in the shared layer.
- **Do:** `shadow-xs/sm/md/lg`; `transition-colors`; tasteful fade-up on scroll.
- **Don't:** glow-stacking, screen-shake, particle effects in shared components (heavy, product-specific
  effects belong inside a product surface — e.g. Nullfal's graph/journey views — not the shared layer).

## 5. Accessible by default
- Color: maintain **WCAG AA** contrast for text and interactive elements in every brand/theme.
- Focus: a visible focus ring driven by `--color-ring` on every interactive element.
- Semantics: real landmarks (`header/nav/main/footer`), buttons vs. links used correctly, `alt` text,
  labelled inputs. Hungarian or English — content language set on `<html lang>`.

## 6. Responsive & fluid
Mobile-first. Containers are centered with sane max-widths (content / wide / marketing). Grids collapse
predictably (`grid-cols-1` → `sm:` → `lg:`). Navs provide a real mobile pattern (drawer or bottom bar).
- **Do:** test at 360px, 768px, 1280px.
- **Don't:** fixed pixel layouts or desktop-only heroes.

## 7. Authoring ergonomics
Components have **simple, typed props**, sensible defaults, and no embedded brand copy. A new page
should be assemblable from the kit without reading internals.
- **Do:** `<Button variant="primary" size="lg">`, `<Hero overline=… title=… />`.
- **Don't:** require consumers to pass class strings to achieve standard variants.

---

## Quick reference — the do/don't card

| Area | Do | Don't |
| --- | --- | --- |
| Color | semantic tokens (`primary`, `surface`, `text-muted`) | inline hex, raw Tailwind palette (`bg-cyan-500`) |
| Type | shared scale + role tokens (`display/sans/mono`) | random font sizes; serif display in shared layer |
| Radius | brand `--radius` scale | hard-coded `rounded-[7px]` |
| Elevation | `shadow-xs…lg` | bespoke glow stacks in shared components |
| Identity | `data-brand` + tokens + tone | forking components per brand |
| Spacing | the 4px scale + section cadence | arbitrary one-off margins |
| Motion | subtle, purposeful | spectacle in shared layer |
| A11y | AA contrast, visible focus, semantics | color-only meaning, missing focus states |

## Resolving conflicts
When two requirements pull apart, prefer in this order:
**Accessibility → Clarity → Brand consistency → Brand distinctiveness → Novelty.**
A brand may be distinctive *after* it is accessible, clear, and consistent with the family.
