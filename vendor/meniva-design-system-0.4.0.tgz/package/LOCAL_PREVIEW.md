# Local Preview — the Design Lab

A local, browser-based environment for inspecting the **whole design system** before running the slow,
billed `/design-sync`. It renders the **real** components from [`src/components`](src/components) against
the **real** stylesheets ([`src/styles/tokens.css`](src/styles/tokens.css) +
[`src/styles/components.css`](src/styles/components.css)) — nothing is duplicated for preview.

Built with **Vite + React + TypeScript**. The lab lives entirely under [`preview/`](preview/).

---

## Install & run

```bash
npm install        # first time only (installs vite + @vitejs/plugin-react)
npm run dev        # start the Design Lab
```

Then open:

```
http://localhost:5173
```

Other scripts:

```bash
npm run build              # tsc --noEmit && vite build  (type-checks + builds the lab)
npm run preview            # serve the production build of the lab
npm run preview:screenshots # capture section screenshots (see "Visual regression" below)
```

---

## What's in it

The left sidebar groups every page:

- **Foundations** — Brand system, LogoLockup (MMNC), Colors, Typography, Tokens.
- **Components** — Button, Card, ArticleCard, ServiceCard, NewsletterSignup, Navbar, Footer, Hero,
  SectionHeader.
- **Stress & examples** — Responsive stress, Page examples (the real `/examples` home pages).

Global controls (top bar):

- **Brand switcher** — Meniva / Metis / Nullfal / CtrlPlane. Recolors the whole preview area via the
  existing `data-brand` approach. Individual pages also pin brands **side by side** for comparison.

Each page renders multiple **background modes** (light / muted / dark / brand / card surface), which
matters most for LogoLockup, Navbar, NewsletterSignup, ArticleCard and Hero.

---

## What to inspect before `/design-sync`

Open **Overview** in the lab for the live checklist. In short:

1. **LogoLockup (MMNC)** — the four marks render (M · M · N · C), icon-only variants have **no leftover
   wordmark gap**, baseline alignment holds at sm/md/lg, dark variants stay readable, and the family
   feels related but distinct. No regression to the old generic stacked icon.
2. **NewsletterSignup** — the **dark / in-card** variant keeps the email input aligned with the button
   and fully inside the card at **320px and 300px** (no slip, no overflow, no detach).
3. **Navbar** — collapses to the mobile toggle in the 320/375 frames; logo + CTA never overflow.
4. **Button / Card / ArticleCard / ServiceCard** — every variant looks right across all four brands on
   light and dark surfaces.
5. **Hero / Footer / SectionHeader** — reflow cleanly at mobile widths.
6. **Tokens** — color, type, spacing, radius and shadow scales feel coherent per brand.
7. **Page examples** — the four home pages read as one family with distinct personalities.

---

## Testing responsive states

Responsive checks use a **`ViewportFrame`** helper that renders components inside an **`<iframe>`** sized
to a fixed width (320 / 375 / 768 / 1024 / full). Because it is a real nested document, the components'
own `@media` breakpoints fire exactly as on device — a plain fixed-width `<div>` cannot do that.

- See the **Responsive stress** page for the full sweep.
- The **Navbar**, **NewsletterSignup**, **Hero** and **ArticleCard** pages each include their own frames.

> The iframe copies the host page's stylesheets once when it mounts. After editing
> `tokens.css`/`components.css`, **reload the page** so the frames pick up the change (Vite HMR updates
> the main document instantly, but not the already-mounted iframe documents).

---

## When to run `/design-sync`

Only **after** the visual pass above is green. `/design-sync` is the slow, billed *publish* step — not
the preview step. Iterate locally with `npm run dev`; run `/design-sync` once the lab looks correct and
you want to push the reviewed state upstream.

---

## Visual regression (optional)

`npm run preview:screenshots` runs [`preview/screenshots.mjs`](preview/screenshots.mjs): it starts the
Vite dev server programmatically and captures full-page PNGs of the main sections at **320 / 768 / 1440**
into `preview-screenshots/`.

It reuses the `playwright-core` + Chromium already available under `.ds-sync/` (no extra dependency). If
that is ever unavailable, the script exits with a clear message — the recommended next step is then:

```bash
npm i -D @playwright/test && npx playwright install chromium
```

…and point the script at `@playwright/test` instead.

---

## Adding a new component preview

1. Create `preview/sections/MyThingPreview.tsx`:

   ```tsx
   import * as React from "react";
   import { MyThing } from "@meniva/design-system";
   import { PageHeader, Stage, Surface } from "../lib/kit";

   export function MyThingPreview() {
     return (
       <div className="lab-page">
         <PageHeader title="MyThing" lead="One line on what this component is for." />
         <Stage title="Default" note="What this stage checks.">
           <Surface mode="light" padded>
             <MyThing /* … */ />
           </Surface>
         </Stage>
       </div>
     );
   }
   ```

2. Register it in [`preview/App.tsx`](preview/App.tsx): import it and add a `SECTIONS` entry
   (`{ id, label, group, el }`). The `id` becomes the URL hash.

3. (Optional) add the `id` to the `SECTIONS` list in
   [`preview/screenshots.mjs`](preview/screenshots.mjs) so it's captured by the screenshot run.

### Kit helpers ([`preview/lib/kit.tsx`](preview/lib/kit.tsx))

- `useBrand()` — the current global brand id.
- `Surface` — background wrapper; `mode="light|muted|dark|brand|card"`, optional `brand`/`dark`. Sets
  `data-brand` + `data-theme` together (required for dark tokens to resolve).
- `BrandRow` — render the same content once per brand, side by side.
- `ViewportFrame` / `ViewportSet` — fixed-width iframes with real breakpoints.
- `PageHeader`, `Stage`, `Checklist`, `Cluster`, `Icons` — small layout/utility primitives.

---

## Known limitations & suggested API additions

The lab surfaced two small gaps in the component APIs (documented inline on the relevant pages):

- **Button** has no `loading` state — the "submitting" sample is simulated with `disabled` + a label.
  Suggested minimal API: `loading?: boolean` that sets `aria-busy`, disables the button, and renders a
  spinner slot before `children`.
- **NewsletterSignup** has no explicit error/invalid prop — invalid input relies on native HTML5
  validation. Suggested minimal API: `error?: React.ReactNode` that renders a styled message and sets
  `aria-invalid` on the input.
