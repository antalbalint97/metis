# Migration Guide — `@meniva/design-system`

This guide covers in-progress, backward-compatible migrations. Nothing here
requires consumer changes in the current phase.

---

## 1. Brand id: `nullfal` → `nullfall`

**Canonical id is now `nullfall` (double L).** `nullfal` (single L) is a
**temporary backward-compatibility alias** and is fully supported in this phase.

### What changed (additive only)
- `tokens.css` — the `nullfal` token blocks (light + dark) now also match
  `nullfall`. Both spellings share one declaration block → **identical tokens**.
- `BrandId` (in `src/index.ts`) now includes both `"nullfall"` and `"nullfal"`.
- `LogoLockup` accepts `brand="nullfall"` and `brand="nullfal"` (same mark + wordmark).

### What consumers should do
- **Now:** nothing is required. Existing `data-brand="nullfal"` keeps working.
- **New code:** prefer `data-brand="nullfall"` and `BrandId === "nullfall"`.
- **Later (separate phase, not yet):** migrate existing `nullfal` usages to
  `nullfall`, then the `nullfal` alias can be deprecated and eventually removed.
  Removal is **out of scope** here and will be its own breaking (major) release.

### Normalization tip for app code
When reading a brand id from config/CMS, normalize before use:
```ts
const canonical = (b: string): BrandId => (b === "nullfal" ? "nullfall" : b) as BrandId;
```

---

## 2. Distribution: source-resolved today, `dist/` later

The package now builds a `dist/` artifact (`npm run build`), **but the resolved
entry is still `src/`** (`exports`/`main`/`module`/`types` point at `src/index.ts`).

**Rationale:** this phase preserves the existing vendored-tarball, source-based
distribution exactly. `dist/` is built, validated, and shipped in the tarball so
it is ready, but switching the resolution is a deliberate later step.

### Future switch (not in this phase)
1. Point `exports`/`main`/`module`/`types` at `dist/` equivalents.
2. Re-pack and re-vendor the tarball into each consumer.
3. Verify each consumer's bundler resolves `dist/` (extensionless ESM relative
   imports require a bundler — all current consumers use Next/Vite/CRA, which do).

---

## 3. Distribution channel: vendored tarball (unchanged)

Distribution remains a vendored `.tgz` copied into each consumer's `vendor/`.
**GitHub Packages / registry publishing is intentionally deferred** until the
shared-package APIs stabilize. No consumer wiring changes in this phase.
