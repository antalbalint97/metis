# Release Checklist — `@meniva/design-system`

A release produces a versioned, vendorable `.tgz`. Distribution is still a
vendored tarball (no registry publish this phase).

## Pre-release gates (all must pass)
```bash
npm run typecheck        # tsc --noEmit — no type errors
npm run validate:tokens  # token JSON parses
npm run build            # emits dist/ (JS + .d.ts + styles + tokens)
npm run validate:package # dist artifacts + nullfal/nullfall parity + tarball contents
npm run dev              # Design Lab still boots (manual smoke; Ctrl-C to stop)
```

## Versioning policy (SemVer)
- **patch** (`0.2.x`) — bug fixes, token value tweaks, no API/contract change.
- **minor** (`0.x.0`) — additive: new components/props, new brand ids, new build
  artifacts. (This release, `0.2.0`, is a minor: alias + build, fully backward compatible.)
- **major** (`x.0.0`) — breaking: removing the `nullfal` alias, switching the
  resolved entry from `src/` to `dist/`, renaming/removing component APIs.

## Release steps
1. Land all changes; ensure gates above pass.
2. Bump `version` in `package.json` (done for this release: `0.2.0`).
3. Update `CHANGELOG.md` (new version section, dated).
4. `npm pack` → produces `meniva-design-system-<version>.tgz` (runs `prepack` → build).
5. Inspect the tarball (`npm pack --dry-run`): confirm `src/`, `dist/`, `tokens/`,
   `*.md`; confirm **no** `.ds-sync/`, `ds-bundle/`, `.design-sync/`, `preview/`.
6. Vendor the tarball into consumers **only when explicitly approved** (out of
   scope for the current phase).

## Versioning & tag recommendation
This repo is **not yet a git repository**. Recommended (owner action, separate
from this phase — not performed here):
```bash
git init && git add -A && git commit -m "chore: DS 0.2.0 — buildable dist + nullfall alias"
git remote add origin <repo-url>
git tag -a v0.2.0 -m "@meniva/design-system 0.2.0"
git push -u origin main --tags
```
- **Tag scheme:** `vMAJOR.MINOR.PATCH` (e.g. `v0.2.0`), one tag per release,
  matching `package.json` `version`.
- Tagging the source of truth is the highest-leverage recoverability fix
  (the DS currently has no remote backup).

## Rollback
- All `0.2.0` changes are additive and confined to this repo.
- Revert: `rm -rf dist/`, restore `package.json` scripts/version/files,
  remove `tsconfig.build.json`, `scripts/`, and the new `*.md`.
- The `nullfal` alias is never removed, so reverting cannot break consumers.
