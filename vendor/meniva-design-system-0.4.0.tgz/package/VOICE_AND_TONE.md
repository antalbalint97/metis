# Voice & Tone — Meniva Ecosystem

The visual system makes the brands *look* related. Voice makes them *sound* distinct. This document
gives each brand a clear personality, do/don't copy direction, and concrete examples.

> Note on language: Metis and parts of Meniva ship in **Hungarian**; Nullfal and CtrlPlane are
> English-first. The *voice* below is language-independent — apply the same personality in either
> language. Examples are given in the brand's primary language where it matters.

---

## Shared voice foundation (all brands)
Before personality, everything in the family shares a baseline:
- **Clear over clever.** Plain language first; jargon only when it adds precision.
- **Respect the reader's intelligence and time.** No hype, no fake urgency, no dark patterns.
- **Concrete over abstract.** Show the outcome, the step, the example.
- **Honest.** No invented numbers, no overpromising. If something is a proposal or beta, say so.
- **Active voice, second person.** "You'll learn…", "We build…", not "It is built…".

What the whole family avoids:
> ❌ "Revolutionary, world-class, next-gen, synergy, unlock infinite potential, game-changing."
> ❌ Manufactured scarcity ("Only 2 spots left!!!"), exclamation spam, ALL-CAPS shouting (outside
>    sanctioned display headlines).

---

## Meniva — *calm, credible, senior*

**Personality:** the expert partner in the room who has seen this before and turns complexity into a
clear plan. Outcome-oriented, quietly confident, never salesy.

**Tone dials:** Warmth ▓▓▓░░ · Authority ▓▓▓▓▓ · Playfulness ▓░░░░ · Formality ▓▓▓▓░

**Do**
- Lead with the business outcome, then the method. ("Fewer manual reports, faster decisions — here's how.")
- Quantify when you can ("~250k€ annual cost reduction"), and only with real numbers.
- Speak to senior stakeholders: clarity, risk, ROI, reliability.

**Don't**
- Don't drown the reader in tooling name-drops. Tools serve outcomes, not the reverse.
- Don't hype. Credibility is the brand.

**Good copy direction**
> *Overline:* DATA · BI · AI · AUTOMATION
> *Headline:* "Turn scattered data into systems you can run the business on."
> *Lede:* "We design and build the data, analytics, and automation layer growing teams rely on —
> from foundations to production ML — so decisions are faster and less manual."
> *CTA:* "Book a free consultation"

**Avoid**
> ❌ "🚀 Unlock next-gen AI synergy for your business!!!"

---

## Metis — *warm, human, encouraging*

**Personality:** the patient mentor who believes you can get there and shows you how to think, not
just what to memorize. Structured and professional, but warm — never childish, never condescending.

**Tone dials:** Warmth ▓▓▓▓▓ · Authority ▓▓▓░░ · Playfulness ▓▓░░░ · Formality ▓▓░░░

**Do**
- Speak *to one learner*, encouragingly. ("You don't need to know everything — you need to ask good questions.")
- Emphasize understanding, thinking, and steady progress over shortcuts.
- Acknowledge that learning is hard and that's normal.

**Don't**
- Don't over-promise speed ("learn X in 7 days").
- Don't talk down or over-formalize. Warmth ≠ silliness; keep it grown-up.

**Good copy direction** (Hungarian-first, the brand's real language)
> *Headline:* "Az adatokról ne csak beszélj — gondolkodj is."
> *Lede:* "A Metis tanuló- és gondolkodótér: nem eszközlista, hanem szemlélet. Megtanulsz jó
> kérdéseket feltenni, rálátni egy problémára, és eljutni a valódi megértésig."
> *CTA:* "Olvasd a cikkeket" · "Mentorprogram részletei"

**Avoid**
> ❌ "Légy adat-NINJA 7 nap alatt! 🥷" (hype + childish + false speed)

---

## Nullfal — *efficient, modular, developer-friendly*

**Personality:** a well-built developer tool that respects your time. Practical, system-oriented,
precise. Talks like good documentation: confident, concise, example-led.

**Tone dials:** Warmth ▓▓░░░ · Authority ▓▓▓▓░ · Playfulness ▓▓░░░ · Formality ▓▓░░░

**Do**
- Be concise and structural. Use modules, steps, progress, and concrete tasks.
- Sound like great docs/CLI output: "Run it. See it pass. Move on."
- Lean on mono/code voice for product surfaces (commands, module names, progress).

**Don't**
- Don't over-lean on the "cyberpunk" intensity or empty gamification ("EARN XP NOW!"). The brand is the
  calm, premium **Deep Ocean** look — XP/streaks are quiet reinforcement, not the pitch.
- Don't be vague. Every claim should map to something the learner does, or to a node in the graph.

**Good copy direction**
> *Overline:* GRAPH-NATIVE · PRACTICAL · ENGINEERING
> *Headline:* "Learn engineering as a system, not a playlist."
> *Lede:* "Nullfal maps a curriculum into a living knowledge graph: connected modules, exercises that
> run in your browser, and a path that adapts as you progress. Write code, watch it pass, level up."
> *CTA:* "Start the first track"  ·  *Tagline:* "Graph-native Engineering Education."

**Avoid**
> ❌ "Level up your skills with our AWESOME neon learning quest!!!" (hype + empty gamification).

---

## CtrlPlane — *sharp, analytical, opinionated* (greenfield)

**Personality:** a senior practitioner with a strong, well-argued point of view on AI, data,
software, and how work is changing. Editorial. Has takes — and backs them.

**Tone dials:** Warmth ▓▓░░░ · Authority ▓▓▓▓▓ · Playfulness ▓░░░░ · Formality ▓▓▓░░

**Do**
- Take a position and defend it with reasoning and evidence. "Here's what most teams get wrong about X."
- Be precise and tight. Systems-thinking framing: signals, layers, trade-offs, second-order effects.
- Earn the subscribe with insight, not FOMO.

**Don't**
- Don't be a neutral aggregator ("Top 10 AI links this week"). CtrlPlane has a thesis.
- Don't manufacture controversy. Sharp ≠ inflammatory.

**Good copy direction**
> *Overline:* THE CONTROL PLANE FOR AI, DATA & SYSTEMS
> *Headline:* "Signal, not noise — a working theory of where this is all going."
> *Lede:* "A weekly read for people who build and decide: clear arguments about AI, data
> infrastructure, software, and the shape of technical work. One idea, examined properly."
> *CTA:* "Subscribe" · "Read the latest issue"

**Avoid**
> ❌ "Your weekly AI news roundup!" (no point of view) · ❌ rage-bait headlines.

---

## Tone-matching cheatsheet

| Situation | Meniva | Metis | Nullfal | CtrlPlane |
| --- | --- | --- | --- | --- |
| Greeting a new visitor | "Here's how we help." | "Welcome — let's think this through." | "Here's the system. Start here." | "Here's the thesis." |
| A CTA | "Book a consultation" | "Olvasd a cikkeket" | "Start the first track" | "Subscribe" |
| An error/empty state | "Something's off — let's fix it." | "No worries — try this." | "No results. Adjust filters." | "Nothing here yet." |
| Describing a feature | outcome-first | understanding-first | task/module-first | argument-first |
| Default emoji use | rare | sparing, warm | rare | rare |

## One-line summary per brand
- **Meniva:** *"We turn complexity into systems you can run the business on."*
- **Metis:** *"Learn to think about data, not just use it."*
- **Nullfal:** *"Graph-native engineering education — connected modules, runnable progress."*
- **CtrlPlane:** *"Signal, not noise, on AI, data, and technical work."*
