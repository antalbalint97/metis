import * as React from "react";
import { cn } from "../lib/cn";

export type ArticleCardProps = {
  title: string;
  excerpt?: React.ReactNode;
  href: string;
  /** Display date string (already formatted). */
  date?: string;
  readingTime?: string;
  category?: string;
  /** Optional cover image URL. */
  image?: string;
  /** Footer call-to-action label. */
  cta?: string;
  className?: string;
};

/**
 * ArticleCard — editorial/blog preview (CtrlPlane issues, Metis posts). The
 * whole card is a single link. Mono meta line carries date/reading-time/category.
 */
export function ArticleCard({
  title,
  excerpt,
  href,
  date,
  readingTime,
  category,
  image,
  cta = "Read",
  className,
}: ArticleCardProps) {
  const meta = [category, date, readingTime].filter(Boolean);

  return (
    <a
      href={href}
      className={cn("ds-card", "ds-card--pad-md", "ds-card--interactive", "ds-article-card", className)}
    >
      {image ? <img className="ds-article-card__media" src={image} alt="" loading="lazy" /> : null}

      {meta.length > 0 ? (
        <div className="ds-article-card__meta">
          {meta.map((m, i) => (
            <React.Fragment key={i}>
              {i > 0 ? <span aria-hidden="true">·</span> : null}
              <span>{m}</span>
            </React.Fragment>
          ))}
        </div>
      ) : null}

      <h3 className="ds-article-card__title">{title}</h3>
      {excerpt ? <p className="ds-article-card__excerpt">{excerpt}</p> : null}
      <span className="ds-article-card__footer">{cta} →</span>
    </a>
  );
}
