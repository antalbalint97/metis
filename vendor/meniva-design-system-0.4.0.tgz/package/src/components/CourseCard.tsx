import * as React from "react";
import { cn } from "../lib/cn";
import { Card } from "./Card";
import { renderAction } from "../lib/renderAction";
import type { Action } from "./types";

export type CourseCardProps = {
  title: string;
  /** Level/track badge, e.g. "JUNIOR–MEDIOR" or "Module 1". */
  level?: string;
  description: React.ReactNode;
  /** Focus areas / topics shown as a bullet list. */
  topics?: string[];
  topicsLabel?: string;
  /** Mono meta line, e.g. "6 modules · ~4h" or "Python · SQL". */
  meta?: string;
  action?: Action;
  className?: string;
};

/**
 * CourseCard — learning-path / module card. Mirrors the strong Metis "track"
 * card (title + level badge + description + focus list + footer CTA) and also
 * fits Nullfal's modular curriculum. Brand-agnostic via tokens.
 */
export function CourseCard({
  title,
  level,
  description,
  topics,
  topicsLabel = "Focus areas",
  meta,
  action,
  className,
}: CourseCardProps) {
  return (
    <Card padding="md" interactive className={cn("ds-course-card", className)}>
      <div className="ds-course-card__head">
        <h3 className="ds-course-card__title">{title}</h3>
        {level ? <span className="ds-badge">{level}</span> : null}
      </div>

      <p className="ds-course-card__desc">{description}</p>

      {topics && topics.length > 0 ? (
        <>
          <p className="ds-course-card__topics-label">{topicsLabel}</p>
          <ul className="ds-course-card__topics">
            {topics.map((t, i) => (
              <li key={i} className="ds-bullet">
                {t}
              </li>
            ))}
          </ul>
        </>
      ) : null}

      {meta ? <p className="ds-course-card__meta">{meta}</p> : null}

      {action ? (
        <div className="ds-course-card__footer">{renderAction(action, "secondary", "sm")}</div>
      ) : null}
    </Card>
  );
}
