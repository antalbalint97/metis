import * as React from "react";
import { cn } from "../lib/cn";

export type LogoLockupProps = {
  /**
   * Brand id — selects the lettermark and the default wordmark text.
   * `nullfall` is canonical; `nullfal` is a legacy alias (both supported).
   */
  brand?: "meniva" | "metis" | "nullfall" | "nullfal" | "ctrlplane" | (string & {});
  /** Override the wordmark text. Defaults to the brand's display name. */
  wordmark?: string;
  /** Optional small tagline under the wordmark. */
  tagline?: string;
  /**
   * Custom mark/glyph. Defaults to the brand's lettermark (the MMNC family).
   * Pass a final brand SVG here once official assets exist.
   */
  mark?: React.ReactNode;
  /** Render the mark only (no wordmark/tagline). Useful for compact navbars/favicons. */
  iconOnly?: boolean;
  href?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
};

const DEFAULT_WORDMARKS: Record<string, string> = {
  meniva: "Meniva",
  metis: "Metis",
  // The live product wordmark renders "NULLFAL" (NULL bright, FAL muted).
  // `nullfall` is the canonical brand id; `nullfal` is the legacy alias.
  nullfall: "Nullfal",
  nullfal: "Nullfal",
  ctrlplane: "CtrlPlane",
};

/* =============================================================================
   The MMNC lettermark family
   -----------------------------------------------------------------------------
   A coherent set of four marks that read as one family but each carry a distinct
   personality. They share: a 32×32 optical grid, a common stroke weight, the
   same corner discipline, and a recurring "node/dot" accent. Each placeholder
   recolors via `currentColor` (the lockup paints the mark with --color-accent),
   so every mark adapts to brand + light/dark automatically.

     Meniva    M  master blade-mark — the existing, official asset (source of truth)
     Metis     M  open, rounded M + a guiding point — warmer, mentoring, human
     Nullfal   N  N wired with graph nodes — technical, modular, platform-like
     CtrlPlane C  C arc + a centered signal point — sharp, analytical, editorial

   NOTE: Metis, Nullfal and CtrlPlane are *provisional* lettermark directions.
   They are intentionally designed, system-consistent placeholders meant to hold
   the brand grammar until final logo assets are produced — at which point they
   can be swapped in via the `mark` prop or by replacing these components.
   ============================================================================= */

/** Shared stroke weight (in the 32-unit viewBox) so the family reads at one weight. */
const STROKE = 3.2;

/** Meniva — the official mark, embedded as a data URI so the package is self-contained. */
const MENIVA_MARK_SRC =
  "data:image/png;base64," +
  "iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAMAAAAKE/YAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ" +
  "bWFnZVJlYWR5ccllPAAAADNQTFRFHp64x+ftjs7bVrbK4/P2c8PTLKS88fn7OqrBqtrk1e3ynNTg" +
  "ZbzOSLDFgcnXuOHp////MVGV5wAAABF0Uk5T/////////////////////wAlrZliAAAElklEQVR4" +
  "2uzd627bMAwFYF0o35I0ev+nLbalQJdGskjxFqD+3/nbSciTxqgd6hse4Rf9i35LdPw60uP4yHn3" +
  "hb7kx7GEzgGu0BBGjuLr7VGG0OAKHTFBe0FnTNBO0HdU0E7QGypoH+gLLmgX6HXBBe0CnZBBe0CP" +
  "9cq3oD2gCzZoB+iIDtoBOqODtkcTgrZHb/igzdE7IWhr9GCvlO6vW6lxrKa98hT0M7r1U0moV8aC" +
  "vlYS+vn/qtorIRLRWcJ8jJlzJaLD3axXfgQ9jt74ZzESgx5HC8ziRgwagWafxZ0aNAadTXrlRdAY" +
  "NPMsJnLQKDTrLAI9aBSadRYLPWgcmnEWB3vlZdBIdNbulVzn0WHX7ZXXQWPRy6raK41XFokOH5q9" +
  "0ggajQ6HYq+0RgiNznq90goaj2aYRZgMmoCen8UyGTQBPT2Lo73SfiMS0LOzmGeDJqGzSq90zkJB" +
  "z83iYK/0PgiT0DOzONornXcHDT0xi6O9IoCmz+Jor0igs3CviKCps1iCJZo2i0cwRdNmMRujKbMY" +
  "gzU6y/WKHDpcxHpFEI2dxfFeEUQ/X77h6xVJdO/fneoVUfRNqFdE0ZhZPIIXNGIWsxv0+CzG4Ac9" +
  "PIubJ/RNolek0WOziOwVcfTQLKbgCz0yi7B4Qw/MYgnu0Df2XlFAn85i9og+mcUYPKJPZnEzRGfi" +
  "LO7BEA20WaT0Ch+62xAX1l5hRPfenM1ZhMUY3VsDV85e4UTXK/ocRzBH92ZxY+wVVnT3xU58vcKL" +
  "7iEWYOsVXnS9oWZxDy7QO+Y05F5hRtcFMYspOEF3IYmpV7jR3b+k+X8WS/CC7lOuPL3Cjo6jZ8qO" +
  "0N2t920WY/CE7i/fxNEr/Og+52sW91lz79dlArq/fq8MvdL8LENHrwMvawrO0CcLeJvvFQn0cXq2" +
  "EtyhT1bwAkdwiD5ZDdfsET2/hC3Q6R3RKxNsuSmiWdbDH1jWRB88Qa+q6Mq0IHTRd5agldEcWy9V" +
  "bfSFI2ht9PyHz1TV0dNb7+9X2tpoYAhaHT259f5dO1BH3+eD1kdPbb3HRRp99GU6aAP0xNb7uhqm" +
  "j57Yeqmaoelbb7VDd6/R9Y5SDdHUbxnBEk3ceqWaove5oHu/IcuhSVuvVFt0/ZgK2ggNU0EboQlb" +
  "D+zRcSZoKzR664EH9D4RtBkaufXABRr3FWqpPtBAD9oOjflYXaoXdCQHbYjuXy7vBW2J3qlBW6Lr" +
  "QgzaFJ2IQZuigRi0KXps64EzdKQFbYse+QoV3KF3UtDG6POP1eAQnShBW6NXStA86Ng+TtAnW6/x" +
  "9zvQPh8MoyeOgxA08WC8lXPGB22P7m296BXd2XrMt0TlRCeloFnRzS8TuO8DzXpP9aQTNC+6ETX7" +
  "Dbd5716fVIJmRr+Mmv/O5szPCUgaQXOjX0QtcAt57icyJIWg2dE/opa4Vz/7sy+KfND8aJAPWuAp" +
  "I0U8aAE0iAct8TyXIh20BBqkgxZ5ck4RDloEDcJByzyjqMgGLYMG2aCFngZVRIMWQkfRoKWeu5Ul" +
  "g5ZCR8mgxZ5wlgWDFkNHwaDlniUH74iWPD4FGABbupJvZK6M3gAAAABJRU5ErkJggg==";

/** Meniva — the official blade "M". Raster asset; carries its own cyan. */
function MenivaMark({ size = 28 }: { size?: number }) {
  return <img src={MENIVA_MARK_SRC} width={size} height={size} alt="" aria-hidden="true" />;
}

/** Metis — an open, rounded "M" with a guiding point of light above the path. */
function MetisMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path
        d="M5 26 V9 L16 20 L27 9 V26"
        stroke="currentColor"
        strokeWidth={STROKE}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="5.2" r="2.2" fill="currentColor" />
    </svg>
  );
}

/** Nullfal — an "N" wired as a graph: emphasized nodes on the diagonal, smaller ones at the feet. */
function NullfalMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path
        d="M6 26 V6 L26 26 V6"
        stroke="currentColor"
        strokeWidth={STROKE}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="6" cy="6" r="2.5" fill="currentColor" />
      <circle cx="26" cy="26" r="2.5" fill="currentColor" />
      <circle cx="26" cy="6" r="1.7" fill="currentColor" />
      <circle cx="6" cy="26" r="1.7" fill="currentColor" />
    </svg>
  );
}

/** CtrlPlane — a sharp "C" arc enclosing a centered signal point (the control plane / lens). */
function CtrlPlaneMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path
        d="M25 10 A9 9 0 1 0 25 22"
        stroke="currentColor"
        strokeWidth={STROKE}
        strokeLinecap="round"
      />
      <circle cx="16" cy="16" r="2.7" fill="currentColor" />
    </svg>
  );
}

/** Brand → lettermark renderer. Falls back to the Meniva master mark for unknown brands. */
const BRAND_MARKS: Record<string, (props: { size?: number }) => React.ReactElement> = {
  meniva: MenivaMark,
  metis: MetisMark,
  // `nullfall` (canonical) and `nullfal` (legacy alias) share one mark.
  nullfall: NullfalMark,
  nullfal: NullfalMark,
  ctrlplane: CtrlPlaneMark,
};

/**
 * LogoLockup — lettermark + wordmark (+ optional tagline). Each brand has its own
 * mark from the MMNC family; pass `mark` to override, or `iconOnly` for the glyph
 * alone. Renders a link when `href` is set.
 */
export function LogoLockup({
  brand = "meniva",
  wordmark,
  tagline,
  mark,
  iconOnly = false,
  href,
  size = "md",
  className,
}: LogoLockupProps) {
  const label = wordmark ?? DEFAULT_WORDMARKS[brand] ?? brand;
  const markSize = size === "sm" ? 22 : size === "lg" ? 34 : 28;
  const MarkComponent = BRAND_MARKS[brand] ?? MenivaMark;

  const inner = (
    <>
      <span className="ds-logo__mark">{mark ?? <MarkComponent size={markSize} />}</span>
      {iconOnly ? null : (
        <span className="ds-logo__text">
          <span className="ds-logo__word">{label}</span>
          {tagline ? <span className="ds-logo__tagline">{tagline}</span> : null}
        </span>
      )}
    </>
  );

  const classes = cn("ds-logo", `ds-logo--${size}`, iconOnly && "ds-logo--icon", className);

  if (href) {
    return (
      <a className={classes} href={href} aria-label={label}>
        {inner}
      </a>
    );
  }
  // When the wordmark is hidden the glyph still needs an accessible name.
  return (
    <span className={classes} aria-label={iconOnly ? label : undefined} role={iconOnly ? "img" : undefined}>
      {inner}
    </span>
  );
}
