"use client";

import * as React from "react";
import { cn } from "../lib/cn";
import { renderAction } from "../lib/renderAction";
import type { Action, NavItem } from "./types";

export type NavbarProps = {
  /** Brand logo node — typically a <LogoLockup />. */
  logo?: React.ReactNode;
  items?: NavItem[];
  /** Primary call-to-action shown on the right (e.g. "Book a consultation"). */
  action?: Action;
  sticky?: boolean;
  container?: "content" | "wide" | "marketing";
  className?: string;
};

/** Minimal inline icons so the component has zero icon-library dependency. */
function MenuIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
function CloseIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

/**
 * Navbar — banded header with logo + links + a primary action. Includes an
 * accessible mobile toggle (no animation library needed). The structure is the
 * shared one across the ecosystem; brand identity comes from tokens.
 */
export function Navbar({
  logo,
  items = [],
  action,
  sticky = true,
  container = "wide",
  className,
}: NavbarProps) {
  const [open, setOpen] = React.useState(false);

  const links = (mobile = false) =>
    items.map((item) => (
      <a
        key={item.href}
        href={item.href}
        className={cn("ds-navbar__link", item.active && "ds-navbar__link--active")}
        aria-current={item.active ? "page" : undefined}
        onClick={mobile ? () => setOpen(false) : undefined}
      >
        {item.icon ? <span className="ds-btn__icon">{item.icon}</span> : null}
        {item.label}
      </a>
    ));

  return (
    <header className={cn("ds-navbar", sticky && "ds-navbar--sticky", className)}>
      <div className={cn("ds-container", `ds-container--${container}`)}>
        <div className="ds-navbar__inner">
          <div className="ds-navbar__right">
            {logo ? <div className="ds-navbar__brand">{logo}</div> : null}
            <nav className="ds-navbar__links" aria-label="Main">
              {links()}
            </nav>
          </div>

          <div className="ds-navbar__right">
            {action ? renderAction(action, "primary", "md") : null}
            {items.length > 0 && (
              <button
                type="button"
                className="ds-navbar__toggle"
                aria-label={open ? "Close menu" : "Open menu"}
                aria-expanded={open}
                onClick={() => setOpen((v) => !v)}
              >
                {open ? <CloseIcon /> : <MenuIcon />}
              </button>
            )}
          </div>
        </div>

        {open && items.length > 0 ? (
          <nav className="ds-navbar__mobile" aria-label="Mobile">
            {links(true)}
          </nav>
        ) : null}
      </div>
    </header>
  );
}
