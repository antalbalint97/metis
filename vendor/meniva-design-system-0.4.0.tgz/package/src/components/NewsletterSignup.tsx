"use client";

import * as React from "react";
import { cn } from "../lib/cn";

export type NewsletterSignupProps = {
  title: string;
  description?: React.ReactNode;
  placeholder?: string;
  buttonLabel?: string;
  note?: React.ReactNode;
  layout?: "inline" | "stacked";
  successMessage?: string;
  /** Called with the email on submit. Wire to your email provider. */
  onSubmit?: (email: string) => void | Promise<void>;
  className?: string;
};

/**
 * NewsletterSignup — email capture (CtrlPlane subscribe, Meniva lead magnet,
 * Metis updates). Self-contained form state; brand-agnostic styling via tokens.
 * No copy is hard-coded — pass title/description/labels in.
 */
export function NewsletterSignup({
  title,
  description,
  placeholder = "you@example.com",
  buttonLabel = "Subscribe",
  note,
  layout = "inline",
  successMessage = "Thanks — check your inbox to confirm.",
  onSubmit,
  className,
}: NewsletterSignupProps) {
  const [email, setEmail] = React.useState("");
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    await onSubmit?.(email);
    setSubmitted(true);
  };

  return (
    <div className={cn("ds-newsletter", className)}>
      <h2 className="ds-newsletter__title">{title}</h2>
      {description ? <p className="ds-newsletter__desc">{description}</p> : null}

      {submitted ? (
        <p className="ds-newsletter__success" role="status">
          {successMessage}
        </p>
      ) : (
        <form
          className={cn("ds-newsletter__form", layout === "inline" && "ds-newsletter__form--inline")}
          onSubmit={handleSubmit}
        >
          <label className="ds-visually-hidden" htmlFor="ds-newsletter-email">
            Email address
          </label>
          <input
            id="ds-newsletter-email"
            className="ds-input"
            type="email"
            inputMode="email"
            autoComplete="email"
            required
            placeholder={placeholder}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button className="ds-btn ds-btn--primary ds-btn--md" type="submit">
            {buttonLabel}
          </button>
        </form>
      )}

      {note ? <p className="ds-newsletter__note">{note}</p> : null}
    </div>
  );
}
