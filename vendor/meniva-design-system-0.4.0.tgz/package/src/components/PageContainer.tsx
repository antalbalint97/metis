import * as React from "react";
import { cn } from "../lib/cn";

export type PageContainerSize = "prose" | "content" | "wide" | "marketing";

export type PageContainerProps = React.HTMLAttributes<HTMLElement> & {
  /**
   * Centered max-width band:
   * - prose/content: readable measures
   * - wide: default page content
   * - marketing: full landing-page width
   */
  size?: PageContainerSize;
  /** Render as a different element, e.g. "main", "section", or "article". */
  as?: React.ElementType;
};

export function PageContainer({
  size = "wide",
  as: Tag = "div",
  className,
  ...rest
}: PageContainerProps) {
  return (
    <Tag
      className={cn("ds-container", `ds-container--${size}`, className)}
      {...rest}
    />
  );
}
