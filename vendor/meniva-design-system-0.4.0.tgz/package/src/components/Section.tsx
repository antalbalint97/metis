import * as React from "react";
import { cn } from "../lib/cn";
import { PageContainer, type PageContainerSize } from "./PageContainer";
import { SectionHeader, type SectionHeaderProps } from "./SectionHeader";

export type SectionSpacing = "tight" | "default" | "lg";

export type SectionProps = React.HTMLAttributes<HTMLElement> & {
  /** Vertical rhythm. `default` is the normal page section cadence. */
  spacing?: SectionSpacing;
  /** Optionally wrap section content in a shared page container. */
  container?: false | PageContainerSize;
  /** Optional shared header rendered before children inside the container. */
  header?: SectionHeaderProps;
  /** Render as a different element. Defaults to "section". */
  as?: React.ElementType;
};

export function Section({
  spacing = "default",
  container = false,
  header,
  as: Tag = "section",
  className,
  children,
  ...rest
}: SectionProps) {
  const body = (
    <>
      {header ? <SectionHeader {...header} /> : null}
      {children}
    </>
  );

  return (
    <Tag
      className={cn(
        "ds-section",
        spacing === "tight" && "ds-section--tight",
        spacing === "lg" && "ds-section--lg",
        className
      )}
      {...rest}
    >
      {container ? <PageContainer size={container}>{body}</PageContainer> : body}
    </Tag>
  );
}
