import * as React from "react";
import { cn } from "../lib/cn";

export type SectionHeaderProps = {
  /** Small uppercase label in the brand accent color (e.g. "DATA · AI · AUTOMATION"). */
  overline?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  align?: "left" | "center";
  /** Heading level for correct document outline. Defaults to h2. */
  as?: "h1" | "h2" | "h3";
  /** Optional actions (buttons/links) shown under the description. */
  actions?: React.ReactNode;
  className?: string;
};

/**
 * SectionHeader — encodes the shared section hierarchy
 * (overline -> heading -> description -> actions). Use it to start every
 * content section so spacing and type rhythm stay consistent across brands.
 */
export function SectionHeader({
  overline,
  title,
  description,
  align = "left",
  as: Heading = "h2",
  actions,
  className,
}: SectionHeaderProps) {
  return (
    <div
      className={cn(
        "ds-section-header",
        align === "center" && "ds-section-header--center",
        className
      )}
    >
      {overline ? <span className="ds-overline">{overline}</span> : null}
      <Heading className="ds-section-header__title">{title}</Heading>
      {description ? <p className="ds-section-header__desc">{description}</p> : null}
      {actions ? <div className="ds-section-header__actions">{actions}</div> : null}
    </div>
  );
}
