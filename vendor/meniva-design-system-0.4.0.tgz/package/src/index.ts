/**
 * @meniva/design-system — public entry point.
 *
 * Components are styled with token-based `ds-*` classes. Import the stylesheets
 * once at your app root (order matters):
 *
 *   import "@meniva/design-system/styles/tokens.css";
 *   import "@meniva/design-system/styles/components.css";
 *
 * Then set the brand on a wrapping element: <html data-brand="meniva">.
 */

// Components
export { Button } from "./components/Button";
export type { ButtonProps, ButtonVariant, ButtonSize } from "./components/Button";

export { Card } from "./components/Card";
export type { CardProps } from "./components/Card";

export { PageContainer } from "./components/PageContainer";
export type { PageContainerProps, PageContainerSize } from "./components/PageContainer";

export { Section } from "./components/Section";
export type { SectionProps, SectionSpacing } from "./components/Section";

export { SectionHeader } from "./components/SectionHeader";
export type { SectionHeaderProps } from "./components/SectionHeader";

export { Hero } from "./components/Hero";
export type { HeroProps, HeroStat } from "./components/Hero";

export { Navbar } from "./components/Navbar";
export type { NavbarProps } from "./components/Navbar";

export { Footer } from "./components/Footer";
export type { FooterProps, FooterColumn } from "./components/Footer";

export { ServiceCard } from "./components/ServiceCard";
export type { ServiceCardProps } from "./components/ServiceCard";

export { CourseCard } from "./components/CourseCard";
export type { CourseCardProps } from "./components/CourseCard";

export { ArticleCard } from "./components/ArticleCard";
export type { ArticleCardProps } from "./components/ArticleCard";

export { NewsletterSignup } from "./components/NewsletterSignup";
export type { NewsletterSignupProps } from "./components/NewsletterSignup";

export { LogoLockup } from "./components/LogoLockup";
export type { LogoLockupProps } from "./components/LogoLockup";

// Shared types & utilities
export type { Action, NavItem } from "./components/types";
export { cn } from "./lib/cn";
export { renderAction } from "./lib/renderAction";

/**
 * Supported brand ids for the `data-brand` attribute.
 *
 * `nullfall` (double L) is the canonical id and should be used in all new
 * public contracts. `nullfal` (single L) is a temporary backward-compatibility
 * alias that renders identical tokens (see MIGRATION.md); it is NOT removed in
 * this phase.
 */
export type BrandId = "meniva" | "metis" | "nullfall" | "nullfal" | "ctrlplane";
