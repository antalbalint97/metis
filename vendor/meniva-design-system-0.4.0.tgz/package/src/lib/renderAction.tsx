import * as React from "react";
import { cn } from "./cn";
import type { Action } from "../components/types";
import type { ButtonVariant, ButtonSize } from "../components/Button";

/**
 * renderAction — turns an `Action` into a token-styled button/link.
 * Supports the `render` escape hatch so consumers can inject a framework link
 * (e.g. Next.js <Link>) while keeping the design-system styling.
 */
export function renderAction(
  action: Action | undefined,
  variant: ButtonVariant,
  size: ButtonSize = "md"
): React.ReactNode {
  if (!action) return null;
  const className = cn("ds-btn", `ds-btn--${variant}`, `ds-btn--${size}`);

  if (action.render) {
    return action.render({ className, children: action.label });
  }
  if (action.href) {
    return (
      <a className={className} href={action.href} onClick={action.onClick}>
        {action.label}
      </a>
    );
  }
  return (
    <button className={className} onClick={action.onClick} type="button">
      {action.label}
    </button>
  );
}
