# Components — @meniva/design-system

Eleven brand-agnostic React components. They render **token-based `ds-*` classes**, so the same
component adapts to whichever brand is active via `data-brand`. No component hard-codes brand copy or
brand colors.

## Setup (once per app)

```tsx
// 1. Import styles at the app root, in this order:
import "@meniva/design-system/styles/tokens.css";
import "@meniva/design-system/styles/components.css";

// 2. Set the brand (and optional dark theme) on a wrapping element:
//    <html data-brand="meniva">                      → Meniva, light
//    <html data-brand="ctrlplane" data-theme="dark">  → CtrlPlane, dark
```

```tsx
import { Button, Hero, Navbar, LogoLockup } from "@meniva/design-system";
```

**Client vs server:** `Navbar` and `NewsletterSignup` are `"use client"` (they hold state). All others
are server-safe (renderable in React Server Components). In CRA the directive is simply ignored.

**Links:** components that take an `Action` accept a `render` escape hatch so you can inject a framework
link while keeping styling:

```tsx
import Link from "next/link";

<Hero
  title="…"
  primaryAction={{
    label: "Get started",
    render: ({ className, children }) => (
      <Link className={className} href="/start">{children}</Link>
    ),
  }}
/>
```

---

## Button

**Purpose.** The one button primitive. Renders `<a>` when `href` is set, else `<button>`.

**Props.** `variant?: "primary" | "secondary" | "outline" | "ghost" | "link"` (default `primary`) ·
`size?: "sm" | "md" | "lg"` (default `md`) · `fullWidth?` · `leftIcon?` · `rightIcon?` · `href?` ·
plus native button/anchor attributes.

**When to use.** Every button or button-styled link. Don't restyle with raw classes — pick a variant.

**Brand notes.** Colors come from tokens: Meniva primary = cyan, Metis primary = charcoal, Nullfal =
teal (Deep Ocean, dark-first), CtrlPlane = ink/azure. Radius follows the brand (sharp vs soft) automatically.

```tsx
<Button variant="primary" size="lg" href="/contact">Book a consultation</Button>
<Button variant="outline" rightIcon={<ArrowRight />}>View work</Button>
```

---

## Card

**Purpose.** The bordered-surface container that everything sits in.

**Props.** `padding?: "none" | "sm" | "md" | "lg"` (default `md`) · `interactive?` (hover lift + accent
border) · `as?` (element, default `div`) · native div attributes.

**When to use.** Any grouped content. Use `interactive` for clickable cards. ServiceCard/CourseCard/
ArticleCard already build on it.

```tsx
<Card padding="lg" interactive>…</Card>
```

---

## SectionHeader

**Purpose.** The shared section hierarchy: overline → heading → description → actions.

**Props.** `overline?` · `title` (required) · `description?` · `align?: "left" | "center"` ·
`as?: "h1" | "h2" | "h3"` (default `h2`) · `actions?`.

**When to use.** At the top of every content section, so type rhythm and spacing stay consistent.

**Brand notes.** The overline renders in the brand accent. CtrlPlane/Meniva tend to use uppercase
overlines; Metis keeps them gentle.

```tsx
<SectionHeader
  overline="WHAT WE DO"
  title="Data & AI systems for modern teams"
  description="From analytics foundations to production ML."
/>
```

---

## Hero

**Purpose.** The page-opening statement. Same structure as SectionHeader, scaled up, with brand "mood"
via `variant`.

**Props.** `title` (required) · `overline?` · `description?` · `primaryAction?` / `secondaryAction?`
(`Action`) · `variant?: "display" | "panel" | "split"` (default `display`) · `align?: "left" | "center"` ·
`media?` (right side for `split`) · `stats?: { value, label }[]` · `children?`.

**When to use.**
- `display` → high-impact marketing headline (**Meniva**, **CtrlPlane**).
- `panel` → calm bordered surface, inviting tone (**Metis**).
- `split` → copy + media/dashboard (**Nullfal**, Meniva product pages).

```tsx
<Hero
  variant="display"
  align="center"
  overline="DATA · BI · AI · AUTOMATION"
  title={<>Data & AI systems <span>for modern teams</span></>}
  description="We turn scattered data into systems you can run the business on."
  primaryAction={{ label: "Book a consultation", href: "/contact" }}
  secondaryAction={{ label: "View work", href: "#work" }}
  stats={[{ value: "€1.85B", label: "Revenue scale supported" }, { value: "~40h/yr", label: "Saved via automation" }]}
/>
```

---

## Navbar  · `"use client"`

**Purpose.** Banded header: logo + links + primary action, with an accessible mobile toggle.

**Props.** `logo?` (node, usually `<LogoLockup />`) · `items?: NavItem[]` (`{ label, href, active?, icon? }`) ·
`action?: Action` · `sticky?` (default `true`) · `container?: "content" | "wide" | "marketing"` (default `wide`).

**When to use.** Top-level site navigation. Pass `active` per item for the current route.

**Brand notes.** Nullfal benefits from `icon` per item (product feel); Metis/CtrlPlane usually omit icons.

```tsx
<Navbar
  logo={<LogoLockup brand="meniva" href="/" />}
  items={[{ label: "Services", href: "#services" }, { label: "Work", href: "#work", active: true }]}
  action={{ label: "Book a consultation", href: "/contact" }}
/>
```

---

## Footer

**Purpose.** Structured footer: brand block + link columns + bottom bar. All sections optional.

**Props.** `logo?` · `tagline?` · `columns?: { title, links: { label, href }[] }[]` · `social?` ·
`copyright?` · `bottomNote?` · `container?`.

**When to use.** Site footer. Use just `logo` + `copyright` for a minimal Metis-style footer, or full
columns for Meniva/CtrlPlane.

```tsx
<Footer
  logo={<LogoLockup brand="metis" />}
  tagline="Learn to think about data, not just use it."
  columns={[{ title: "Learn", links: [{ label: "Blog", href: "/posts" }] }]}
/>
```

---

## ServiceCard

**Purpose.** Offering/capability card (Meniva services, but generic). Icon tile + title + description +
optional features + footer CTA.

**Props.** `title` · `description` · `icon?` · `features?: string[]` · `action?: Action` ·
`interactive?` (default `true`).

**When to use.** "What we do" / capability grids. Pair inside a `.ds-grid ds-grid--3`.

```tsx
<ServiceCard icon={<Database />} title="Data foundations" description="Clean, reliable pipelines."
  features={["Warehouse modeling", "Quality checks"]} action={{ label: "Learn more", href: "#" }} />
```

---

## CourseCard

**Purpose.** Learning-path / module card. Title + level badge + description + focus list + footer CTA.
Modeled on the strong Metis "track" card; also fits Nullfal modules.

**Props.** `title` · `description` · `level?` (badge) · `topics?: string[]` · `topicsLabel?`
(default "Focus areas") · `meta?` (mono line) · `action?: Action`.

**When to use.** Course/track/module listings.

```tsx
<CourseCard title="Data Analyst" level="JUNIOR-MEDIOR"
  description="Interpret data and answer business questions."
  topics={["SQL & querying", "Descriptive statistics"]}
  meta="6 modules · ~12h" action={{ label: "Open track", href: "/tracks/da" }} />
```

---

## ArticleCard

**Purpose.** Editorial/blog preview (CtrlPlane issues, Metis posts). Whole card is one link; mono meta
line carries category/date/reading-time.

**Props.** `title` · `href` · `excerpt?` · `date?` · `readingTime?` · `category?` · `image?` ·
`cta?` (default "Read").

**When to use.** Post/issue grids and "latest" sections.

```tsx
<ArticleCard href="/issues/12" category="ISSUE 12" date="2026-06-10" readingTime="7 min"
  title="The control plane for AI work" excerpt="One idea, examined properly." />
```

---

## NewsletterSignup  · `"use client"`

**Purpose.** Email capture (CtrlPlane subscribe, Meniva lead magnet, Metis updates). Self-contained
state; success message after submit.

**Props.** `title` · `description?` · `placeholder?` · `buttonLabel?` (default "Subscribe") · `note?` ·
`layout?: "inline" | "stacked"` (default `inline`) · `successMessage?` · `onSubmit?(email)`.

**When to use.** Any signup. Wire `onSubmit` to your provider (no transport is bundled).

```tsx
<NewsletterSignup title="Get the weekly issue"
  description="Signal, not noise, on AI, data, and technical work."
  buttonLabel="Subscribe" onSubmit={(email) => subscribe(email)} />
```

---

## LogoLockup

**Purpose.** Lettermark + wordmark (+ optional tagline). Each brand has its own mark from the **MMNC
lettermark family** — one coherent grammar, four distinct personalities:

| Brand | Letter | Mark | Personality |
| --- | --- | --- | --- |
| Meniva | **M** | the official blade-`M` (real asset, embedded as a data URI) | master, bold, consulting-grade |
| Metis | **M** | open rounded `M` + a guiding point of light | warmer, human, mentoring |
| Nullfal | **N** | `N` wired with graph nodes | technical, modular, platform-like |
| CtrlPlane | **C** | sharp `C` arc enclosing a centered signal point | analytical, editorial, control-plane |

The marks share a 32×32 optical grid, one stroke weight, the same corner discipline, and a recurring
node/dot accent, so they read as a family. The three non-Meniva placeholder marks recolor via
`currentColor` (painted with `--color-accent`), so they adapt to brand + light/dark automatically.

> **Provisional:** the Metis, Nullfal, and CtrlPlane marks are intentionally designed, system-consistent
> **placeholder lettermarks**. They hold the brand grammar until final logo assets exist — at which point
> swap them in via the `mark` prop (or by replacing the mark components in `LogoLockup.tsx`).

**Props.** `brand?` · `wordmark?` · `tagline?` · `mark?` (custom SVG/node override) · `iconOnly?`
(render the bare glyph) · `href?` · `size?: "sm" | "md" | "lg"`.

**When to use.** Navbar and Footer branding. Use `iconOnly` for compact navbars, favicons, or avatars.
Pass a real `mark` once a final asset exists.

```tsx
<LogoLockup brand="nullfal" tagline="Structured learning" href="/" />
<LogoLockup brand="ctrlplane" iconOnly />              // bare lettermark
<LogoLockup brand="meniva" mark={<MyFinalLogo />} />   // override with a final asset
```

---

## Composition cheatsheet

A typical page:

```tsx
<div data-brand="meniva" className="ds-base">
  <Navbar logo={<LogoLockup brand="meniva" href="/" />} items={…} action={…} />
  <main>
    <div className="ds-container ds-container--marketing ds-section">
      <Hero … />
    </div>
    <div className="ds-container ds-container--marketing ds-section">
      <SectionHeader overline="WHAT WE DO" title="…" />
      <div className="ds-grid ds-grid--3" style={{ marginTop: "var(--space-8)" }}>
        <ServiceCard … /><ServiceCard … /><ServiceCard … />
      </div>
    </div>
  </main>
  <Footer … />
</div>
```

See [`../../examples/`](../../examples/) for full per-brand pages.
